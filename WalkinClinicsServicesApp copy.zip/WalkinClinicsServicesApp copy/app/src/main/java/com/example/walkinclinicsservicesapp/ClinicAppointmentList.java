package com.example.walkinclinicsservicesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class ClinicAppointmentList extends ArrayAdapter<ClinicAppointment> {

    private Activity context;
    List<ClinicAppointment> clinics;



    public ClinicAppointmentList (Activity context, List<ClinicAppointment> clinics){
        super(context, R.layout.activity_clinic_list, clinics);
        this.clinics=clinics;
        this.context=context;
    }


    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();

        View listViewItem = inflater.inflate(R.layout.activity_clinic_list, null, true);

        TextView textViewClinicName= (TextView) listViewItem.findViewById(R.id.textViewClinicName);
        TextView textViewClinicAddress= (TextView) listViewItem.findViewById(R.id.textViewClinicAddress);
        TextView textViewClinicPhoneNumber= (TextView) listViewItem.findViewById(R.id.textViewClinicPhoneNumber);
        TextView textViewOpen =(TextView ) listViewItem.findViewById(R.id.textViewOpen);
        TextView textViewClose =(TextView ) listViewItem.findViewById(R.id.textViewClose);

        ClinicAppointment clinic = clinics.get(position);

        textViewClinicName.setText(clinic.getName());
        textViewClinicAddress.setText(clinic.getAddress());
        textViewClinicPhoneNumber.setText(clinic.getPhone());
        String s1 =clinic.getAppointmentDate();
        textViewOpen.setText(s1);
        String s2 ="At :"+clinic.getAppointmentTime();
        textViewClose.setText(s2);

        return listViewItem;

    }


}

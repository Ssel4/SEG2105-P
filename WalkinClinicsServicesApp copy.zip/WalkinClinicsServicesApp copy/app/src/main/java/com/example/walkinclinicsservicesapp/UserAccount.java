package com.example.walkinclinicsservicesapp;

public class UserAccount {

    private String name,email,role;
    private int id;

    public UserAccount(String name,String email,String role ,int id){
        this.name=name;
        this.email=email;
        this.role=role;
        this.id=id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getRole() {
        return role;
    }

    public String getId() {
        return id+"";
    }

}


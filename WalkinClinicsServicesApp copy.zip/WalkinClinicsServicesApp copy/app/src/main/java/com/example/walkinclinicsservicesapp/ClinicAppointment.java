package com.example.walkinclinicsservicesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ClinicAppointment{


    private String name;
    private String address;
    private String phone;
    private String appointmentDate;
    private String appointmentTime;

    public ClinicAppointment(String name,String address,String phone,String appointmentDate,String appointmentTime){
        this.name=name;
        this.address=address;
        this.phone=phone;
        this.appointmentDate=appointmentDate;
        this.appointmentTime=appointmentTime;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getPhone(){
        return phone;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public String getAppointmentTime() {
        return appointmentTime;
    }
}

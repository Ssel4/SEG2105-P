package com.example.walkinclinicsservicesapp;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class UserList extends ArrayAdapter<UserAccount> {


    private Activity context;
    List<UserAccount> users;

    public UserList(Activity context, List<UserAccount> users) {
        super(context, R.layout.userlist, users);
        this.context = context;
        this.users = users;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();

        View listViewItem = inflater.inflate(R.layout.userlist, null, true);

        TextView textViewName = (TextView) listViewItem.findViewById(R.id.textViewName);
        TextView textViewEmail = (TextView) listViewItem.findViewById(R.id.textViewEmail);
        TextView textViewRole = (TextView)  listViewItem.findViewById(R.id.textViewRole);;
        TextView textViewId = (TextView)  listViewItem.findViewById(R.id.textViewId);;
        UserAccount user = users.get(position);

        textViewName.setText(user.getName());
        textViewEmail.setText(String.valueOf(user.getEmail()));
        textViewRole.setText(user.getRole());
        textViewId.setText(user.getId());
        return listViewItem;

    }

}


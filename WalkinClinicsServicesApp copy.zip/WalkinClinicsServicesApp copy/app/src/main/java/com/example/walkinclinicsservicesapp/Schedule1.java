package com.example.walkinclinicsservicesapp;
//

//
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;


public class Schedule1 extends AppCompatActivity {
/*
    //List<WorkingHours> workhours;
    String role,name,email;
    //ListView Schedule;
    Button buttonSelectDayLeft,buttonSelectDayRight,buttonPlusHour,buttonMinusHour,buttonPlusMin,buttonMinusMin,buttonAddClinicWorkHours,buttonDelWorkHourClinicFromEmployeeProfile,buttonPlusHourEnd,buttonMinusHourEnd,buttonPlusMinEnd,buttonMinusMinEnd;
    TextView textViewSelectedDay,textViewHour,textViewMin,textViewHourEnd,textViewMinEnd;

    String [] Day = new String[]{"monday","tuesday","wednesday","thursday","friday","saturday","sunday"};
    int currentDay=  0;
    String[] hours = new String[]{"0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23"};
    int currentHour=8;
    int currentHourEnd=5;
    String[] minuit = new String[]{"00","05","10","15","20","25","30","35","40","45","50","55"};
    int currentMinuit =7;
    int currentMinuitEnd=7;


 */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.schedule_display);
/*
        // DBHelper db = new DBHelper(this);

        //Schedule = (ListView) findViewById(R.id.WorkSchedule);


        role = getIntent().getExtras().getString("role");
        name = getIntent().getExtras().getString("userName");
        email = getIntent().getExtras().getString("email");

        /*
        Schedule.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                WorkingHours workhour= workhours.get(i);
                Clinic clinic = workhour.getClinic();
                //editDeleteSchedule(clinic.getClinicName(),clinic.getAddress(),clinic.getPhoneNumber(),workhour.getDay());
                return true;
            }
        });

         */
    }


    @Override
    protected void onStart() {
        super.onStart();

        //DBHelper db = new DBHelper(this);
       // workhours=db.getAllEmployeeWorkHours(email);



        //creating adapter
        //ScheduleList scheduleAdapter = new ScheduleList(Schedule1.this, workhours);

        //attaching adapter to the listView
        //Schedule.setAdapter(scheduleAdapter);
    }

/*
    public void editDeleteSchedule(final String clinicName, final String address, final String phoneNumber, final String day){


        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.add_clinic_to_employee_profile_dialogue, null);
        dialogBuilder.setView(dialogView);


        final TextView textViewClinicNameDialog = (TextView) dialogView.findViewById(R.id.textViewClinicNameDialog);
        final TextView textViewClinicAddressDialog = (TextView) dialogView.findViewById(R.id.textViewClinicAddressDialog);
        final TextView textViewClinicPhoneNumberDialog = (TextView) dialogView.findViewById(R.id.textViewClinicPhoneNumberDialog);

        textViewClinicNameDialog.setText(clinicName);
        textViewClinicAddressDialog.setText(address);
        textViewClinicPhoneNumberDialog.setText(phoneNumber);


        currentDay=0;
        currentHour=8;
        currentMinuit=7;
        currentHourEnd=5;
        currentMinuitEnd=7;


        //day
        textViewSelectedDay = (TextView) dialogView.findViewById(R.id.textViewSelectedDay);
        textViewSelectedDay.setText(Day[currentDay]);

        //start time
        textViewHour = (TextView) dialogView.findViewById(R.id.textViewHour);
        textViewHour.setText(hours[currentHour]);
        textViewMin = (TextView) dialogView.findViewById(R.id.textViewMin);
        textViewMin.setText(minuit[currentMinuit]);

        //end time
        textViewHourEnd = (TextView) dialogView.findViewById(R.id.textViewHourEnd);
        textViewHourEnd.setText(hours[currentHourEnd]);
        textViewMinEnd = (TextView) dialogView.findViewById(R.id.textViewMinEnd);
        textViewMinEnd.setText(minuit[currentMinuitEnd]);

        //change day
        buttonSelectDayLeft = (Button) dialogView.findViewById(R.id.buttonSelectDayLeft);
        buttonSelectDayRight = (Button) dialogView.findViewById(R.id.buttonSelectDayRight);

        //change start hour
        buttonPlusHour = (Button) dialogView.findViewById(R.id.buttonPlusHour);
        buttonMinusHour = (Button) dialogView.findViewById(R.id.buttonMinusHour);

        //change start min
        buttonPlusMin = (Button) dialogView.findViewById(R.id.buttonPlusMin);
        buttonMinusMin = (Button) dialogView.findViewById(R.id.buttonMinusMin);

        //change end hour
        buttonPlusHourEnd =(Button) dialogView.findViewById(R.id.buttonPlusHourEnd);
        buttonMinusHourEnd =(Button) dialogView.findViewById(R.id.buttonMinusHourEnd);

        //change end min
        buttonPlusMinEnd = (Button) dialogView.findViewById(R.id.buttonPlusMinEnd);
        buttonMinusMinEnd = (Button) dialogView.findViewById(R.id.buttonMinusMinEnd);

        buttonAddClinicWorkHours = (Button) dialogView.findViewById(R.id.buttonAddClinicWorkHours);
        buttonDelWorkHourClinicFromEmployeeProfile = (Button) dialogView.findViewById(R.id.buttonDelWorkHourClinicFromEmployeeProfile);
        buttonDelWorkHourClinicFromEmployeeProfile.setVisibility(View.VISIBLE);

        dialogBuilder.setTitle("Add to Work hours");
        final AlertDialog b = dialogBuilder.create();
        b.show();

        final DBHelper db = new DBHelper(getApplicationContext());
        final int userID = db.userID(this.email,this.role);
        final int clinicID = db.getClinicID(clinicName,address,phoneNumber);
//delete
        buttonDelWorkHourClinicFromEmployeeProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.deleteWorkingHourAndClinicFromEmployeeProfile(userID,clinicID,day);
                b.dismiss();
                onStart();
            }
        });

//update

        //add
        buttonAddClinicWorkHours.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!db.alreadyWorkingThatDay(userID,textViewSelectedDay.getText().toString())){
                    db.updateClinicToEmployeeProfile(userID, clinicID, textViewSelectedDay.getText().toString(),textViewHour.getText().toString()+":"+textViewMin.getText().toString(), textViewHourEnd.getText().toString()+":"+textViewMinEnd.getText().toString());
                    Toast.makeText(Schedule1.this,"Clinic: "+clinicName+"\nAddress: "+address+"\nPhone Number: "+phoneNumber+"\nHas been updated to your schedule profile",Toast.LENGTH_LONG).show();
                    b.dismiss();
                    onStart();


                }
                else{
                    Toast.makeText(Schedule1.this,"Clinic: "+clinicName+"\nAddress: "+address+"\nPhone Number: "+phoneNumber+" \nNot added to your profile due to a schedule conflict",Toast.LENGTH_LONG).show();
                }

            }
        });

        //change day to the left
        buttonSelectDayLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(currentDay==0){
                    currentDay=6;
                    textViewSelectedDay.setText(Day[currentDay]);
                }
                else{
                    currentDay--;
                    textViewSelectedDay.setText(Day[currentDay]);
                }
            }
        });

        //change day to the right
        buttonSelectDayRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(currentDay==6){
                    currentDay=0;
                    textViewSelectedDay.setText(Day[currentDay]);
                }
                else{
                    currentDay++;
                    textViewSelectedDay.setText(Day[currentDay]);
                }
            }
        });

        //increase Start hour
        buttonPlusHour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(currentHour==23){
                    currentHour=0;
                    textViewHour.setText(hours[currentHour]);
                }
                else{
                    currentHour++;
                    textViewHour.setText(hours[currentHour]);
                }
            }
        });

        //reduce Start hour
        buttonMinusHour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(currentHour==0){
                    currentHour=23;
                    textViewHour.setText(hours[currentHour]);
                }
                else{
                    currentHour--;
                    textViewHour.setText(hours[currentHour]);
                }
            }
        });

        //increase Start minuit
        buttonPlusMin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(currentMinuit==11){
                    currentMinuit=0;
                    textViewMin.setText(minuit[currentMinuit]);
                }
                else{
                    currentMinuit++;
                    textViewMin.setText(minuit[currentMinuit]);
                }
            }
        });

        //decrease Start minuit
        buttonMinusMin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(currentMinuit==0){
                    currentMinuit=11;
                    textViewMin.setText(minuit[currentMinuit]);
                }
                else{
                    currentMinuit--;
                    textViewMin.setText(minuit[currentMinuit]);
                }
            }
        });


        //increase End hour
        buttonPlusHourEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(currentHourEnd==23){
                    currentHourEnd=0;
                    textViewHourEnd.setText(hours[currentHourEnd]);
                }
                else{
                    currentHourEnd++;
                    textViewHourEnd.setText(hours[currentHourEnd]);
                }
            }
        });



        //reduce End hour
        buttonMinusHourEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(currentHourEnd==0){
                    currentHourEnd=23;
                    textViewHourEnd.setText(hours[currentHourEnd]);
                }
                else{
                    currentHourEnd--;
                    textViewHourEnd.setText(hours[currentHourEnd]);
                }
            }
        });



        //increase End minuit
        buttonPlusMinEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(currentMinuitEnd==11){
                    currentMinuitEnd=0;
                    textViewMinEnd.setText(minuit[currentMinuitEnd]);
                }
                else{
                    currentMinuitEnd++;
                    textViewMinEnd.setText(minuit[currentMinuitEnd]);
                }
            }
        });

        //decrease End minuit
        buttonMinusMinEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(currentMinuitEnd==0){
                    currentMinuitEnd=11;
                    textViewMinEnd.setText(minuit[currentMinuitEnd]);
                }
                else{
                    currentMinuitEnd--;
                    textViewMinEnd.setText(minuit[currentMinuitEnd]);
                }
            }
        });


    }

 */
}

package com.example.walkinclinicsservicesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.RatingBar;

import java.util.List;

public class RatingClinic extends AppCompatActivity {

    String name, role, email;
    ListView allClinicRating;
    private List<Clinic> clinics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating_clinic);

        role = getIntent().getExtras().getString("role");
        name = getIntent().getExtras().getString("userName");
        email = getIntent().getExtras().getString("email");
        allClinicRating = (ListView) findViewById(R.id.allClinicRating);

        allClinicRating.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

                DBHelper db =new DBHelper(getApplicationContext());
                Clinic clinic= clinics.get(i);
                Bundle bundle = new Bundle();
                bundle.putString("userName",name);
                bundle.putString("role",role);
                bundle.putString("email",email);
                bundle.putString("clinic",clinic.getClinicName());
                bundle.putString("address",clinic.getAddress());
                bundle.putString("phone",clinic.getPhoneNumber());

                Intent intentPatient = new Intent(getApplicationContext(), ClinicProfileRating.class);
                intentPatient.putExtras(bundle);
                startActivityForResult(intentPatient, 0);
                return true;            }
        });


    }

    protected void onStart() {
        super.onStart();

        DBHelper db = new DBHelper(this);
        clinics=db.getAllClinicsThatOfferServices();

        //creating adapter
        ClinicRatingList clinicAdapter = new ClinicRatingList(RatingClinic.this, clinics);

        allClinicRating.setAdapter(clinicAdapter);
    }


}

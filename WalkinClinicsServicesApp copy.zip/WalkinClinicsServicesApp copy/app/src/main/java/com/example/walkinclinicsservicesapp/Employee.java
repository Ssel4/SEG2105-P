package com.example.walkinclinicsservicesapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Employee extends User {

    private Button continueButtonClinics, continueButtonSchedule;
    private DBHelper db;
    private TextView id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);


        role = getIntent().getExtras().getString("role");
        name = getIntent().getExtras().getString("userName");
        email = getIntent().getExtras().getString("email");
//        ID = getIntent().getExtras().getString("ID");

        welcomeMsg = (TextView)findViewById(R.id.textViewWelcome) ;
        welcomeMsg.setText("Welcome "+name+" !\n You are logged in as a "+role);

//        currentID = (TextView)findViewById(R.id.textViewCurrentID);
//        currentID.setText("Current ID# : "+ID);

        currentUserName= (TextView)findViewById(R.id.textViewCurrentUserName);
        currentUserName.setText("UserName : "+name);

        currentEmail=(TextView)findViewById(R.id.textViewCurrentEmail);
        currentEmail.setText("Email : "+email);

        currentRole= (TextView)findViewById(R.id.textViewCurrentRole);
        currentRole.setText("Role : "+role);




        continueButton = (Button)findViewById(R.id.continueButton);
        continueButton.setText("Services");
        continueToEmployeeService();

        continueButtonClinics= (Button) findViewById(R.id.buttonClinicMenu);
        continueButtonClinics.setText("Clinic Menu");
        continueButtonClinics.setVisibility(View.VISIBLE);
        continueToClinicSelection();


        continueButtonSchedule= (Button) findViewById(R.id.buttonSchedule1);
        continueButtonSchedule.setText("View Schedule");
        continueButtonSchedule.setVisibility(View.VISIBLE);
        continueToCurrentSchedule();

    }

    public void continueToEmployeeService(){
        final Bundle bundle=new Bundle();
        bundle.putString("userName",name);
        bundle.putString("role",role);
        bundle.putString("email",email);

        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                
                Intent intent = new Intent(getApplicationContext(), EmployeeService.class);
                intent.putExtras( bundle);
                startActivityForResult(intent, 0);
            }
        });
    }

    public void continueToClinicSelection(){
        final Bundle bundle=new Bundle();
        bundle.putString("userName",name);
        bundle.putString("role",role);
        bundle.putString("email",email);

        continueButtonClinics.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent intent =  new Intent (getApplicationContext(), ClinicMenu.class);
                intent.putExtras( bundle);
                startActivityForResult(intent,0);
            }
        });
    }

    public void continueToCurrentSchedule(){
        final Bundle bundle=new Bundle();
        bundle.putString("userName",name);
        bundle.putString("role",role);
        bundle.putString("email",email);

        continueButtonSchedule.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent =  new Intent (getApplicationContext(), Schedule.class);
                intent.putExtras( bundle);
                startActivityForResult(intent,0);
            }
        });
    }


}

package com.example.walkinclinicsservicesapp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.sql.Time;
import java.util.Calendar;

public class BookAppointment extends AppCompatActivity {

    String role,name,email,clinicName,clinicAddress,clinicPhone;
    Clinic clinic;
    Button SelectDate, SelectTime ,confirmBooking;
    TextView  textViewDate,textViewTime , open, close,waitTime;

    TimePickerDialog timePickerDialogue;

    DatePickerDialog datePickerDialog;
    Calendar calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_appointment);

        final DBHelper db =new DBHelper(this);
        role = getIntent().getExtras().getString("role");
        name = getIntent().getExtras().getString("userName");
        email = getIntent().getExtras().getString("email");
        clinicName= getIntent().getExtras().getString("clinic");
        clinicAddress = getIntent().getExtras().getString("address");
        clinicPhone = getIntent().getExtras().getString("phone");
        clinic = db.getClinic(clinicName,clinicAddress,clinicPhone);

        open = (TextView) findViewById(R.id.open);
        open.setText("Clinic opens at : "+clinic.getOpensAt());
        close = (TextView) findViewById(R.id.close);
        close.setText("Clinic closes at : "+clinic.getClosesAt());
        waitTime = (TextView) findViewById(R.id.waitTime);


        textViewDate = (TextView) findViewById(R.id.textViewDate);
        textViewDate.setText("Date");
        textViewTime = (TextView)findViewById(R.id.textViewTime);
        textViewTime.setText("Time");

        SelectDate = (Button) findViewById(R.id.SelectDate);
        SelectDate.setText("Date");

        SelectDate.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {

                calendar = Calendar.getInstance();

                int day=calendar.get(Calendar.DAY_OF_MONTH);
                int month = calendar.get((Calendar.MONTH));
                int year = calendar.get(Calendar.YEAR);

                datePickerDialog = new DatePickerDialog(BookAppointment.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        textViewDate.setText(dayOfMonth +"/" + (month+1) +"/"+  year);
                        String tmp =db.getWaitTime(db.getClinicID(clinicName,clinicAddress,clinicPhone),textViewDate.getText().toString())+" minutes wait time";
                        waitTime.setText(tmp);
                    }
                },day,month,year);
                datePickerDialog.show();
            }
        });


        SelectTime = (Button) findViewById(R.id.SelectTime);
        SelectTime.setText("Time");

        SelectTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                timePickerDialogue =new TimePickerDialog(BookAppointment.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minute) {
                        textViewTime.setText(String.format("%02d:%02d",hourOfDay,minute));
                    }
                },00,00,true);
                timePickerDialogue.show();
            }
        });


        confirmBooking = (Button) findViewById( R.id.confirmBooking);
        confirmBooking.setText("confirm booking");
        confirmBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!(textViewTime.getText().toString().equals("Time")) && !(textViewDate.getText().toString().equals("Data"))){

                    if( db.isValideTime( db.getClinicID(clinicName,clinicAddress,clinicPhone),textViewTime.getText().toString())){
                        db.bookAppointment(db.userID(email,role),db.getClinicID(clinicName,clinicAddress,clinicPhone),textViewDate.getText().toString(),textViewTime.getText().toString());
                        Toast.makeText(BookAppointment.this,"Appointment Added",Toast.LENGTH_SHORT).show();
                        finish();
                    }
                    else{
                        Toast.makeText(BookAppointment.this,"Clinic is not open at time selected",Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(BookAppointment.this,"Select date and time",Toast.LENGTH_SHORT).show();

                }


            }
        });



    }
}

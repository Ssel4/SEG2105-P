package com.example.walkinclinicsservicesapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class EmployeeService extends AppCompatActivity {


    Button addServiceButton, addNewServiceButton;
    ListView listViewServices;
    List<Service> services;
    private static final String[] employeeRole ={ "Staff", "Doctor","Nurse"};
    String name,email,role;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_service);

        role = getIntent().getExtras().getString("role");
        name = getIntent().getExtras().getString("userName");
        email = getIntent().getExtras().getString("email");

        listViewServices= (ListView)  findViewById(R.id.listViewEmployeeServices);


        addServiceButton = (Button)findViewById(R.id.addServiceEmployeeButton);
        addEmployeeService();

        listViewServices.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                Service service = services.get(i);
                showDeleteDialog(service.getServiceName(), service.getEmployeeRole());
                return true;
            }
        });

        //onStart();
    }

    @Override
    protected void onStart() {
        super.onStart();

        DBHelper dbServices = new DBHelper(this);
        services=dbServices.getAllEmployeeServices(email);

        //creating adapter
        ServiceList serviceAdapter = new ServiceList(EmployeeService.this, services);

        //attaching adapter to the listview
        listViewServices.setAdapter(serviceAdapter);
    }


    public void addEmployeeService(){
            final Bundle bundle=new Bundle();
            bundle.putString("userName",name);
            bundle.putString("role",role);
            bundle.putString("email",email);


            addServiceButton.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {

                    Intent intent = new Intent(getApplicationContext(), AddServiceToEmployeeProfile.class);
                    intent.putExtras( bundle);
                    startActivityForResult(intent, 0);
                }
            });
    }


    private void showDeleteDialog(final String serviceName, final String emprole){

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.del_service_employee_dialogue, null);
        dialogBuilder.setView(dialogView);


        final TextView TextServiceName = (TextView) dialogView.findViewById(R.id.textViewDelServiceNameEmployeeProfile);
        final TextView TextRole  = (TextView) dialogView.findViewById(R.id.textViewDelServiceRoleEmployeeProfile);

        TextRole.setText(emprole);
        TextServiceName.setText(serviceName);

        final Button buttonDelete = (Button) dialogView.findViewById(R.id.buttonDelToEmployeeProfile);

        dialogBuilder.setTitle("Remove Service: ");
        final AlertDialog b = dialogBuilder.create();
        b.show();


        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelper db = new DBHelper(getApplicationContext());
                db.removeServiceFromEmployeeProfile(db.userID(email,role),db.getServiceID(serviceName,emprole));
                b.dismiss();
                onStart();
                Toast.makeText(EmployeeService.this,"Service removed.",Toast.LENGTH_SHORT).show();
            }
        });
    }



}

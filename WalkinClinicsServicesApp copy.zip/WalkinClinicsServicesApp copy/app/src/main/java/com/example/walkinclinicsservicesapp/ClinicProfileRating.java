package com.example.walkinclinicsservicesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

public class ClinicProfileRating extends AppCompatActivity {

    String role,name,email,clinicName,clinicAddress,clinicPhone;
    Clinic clinic;
    int rating;
    TextView clinicNameText,ClinicAddress,ClinicPhoneNumber,openTime,closeTime;
    Button book;
    RatingBar ratingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clinic_profile);

        final DBHelper db = new DBHelper(this);


        role = getIntent().getExtras().getString("role");
        name = getIntent().getExtras().getString("userName");
        email = getIntent().getExtras().getString("email");
        clinicName= getIntent().getExtras().getString("clinic");
        clinicAddress = getIntent().getExtras().getString("address");
        clinicPhone = getIntent().getExtras().getString("phone");
        rating = getIntent().getExtras().getInt("rating");
        clinic = db.getClinic(clinicName,clinicAddress,clinicPhone);



        clinicNameText = (TextView) findViewById(R.id.clinicName);
        clinicNameText.setText(clinic.getClinicName());
        ClinicAddress = (TextView) findViewById(R.id.ClinicAddress);
        ClinicAddress.setText(clinic.getAddress());
        ClinicPhoneNumber = (TextView) findViewById(R.id.ClinicPhoneNumber);
        ClinicPhoneNumber.setText(clinic.getPhoneNumber());
        openTime = (TextView) findViewById(R.id.openTime);
        openTime.setText(clinic.getOpensAt());
        closeTime = (TextView) findViewById(R.id.closeTime);
        closeTime.setText(clinic.getClosesAt());
        ratingBar = (RatingBar) findViewById(R.id.ratingClinic);


        book = (Button) findViewById(R.id.book);
        book.setText("Add Rating");
        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.addRating(clinic, (int) ratingBar.getRating());
                finish();
            }
        });
    }

}

package com.example.walkinclinicsservicesapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class AddServiceToEmployeeProfile extends AppCompatActivity {


    private ListView listViewServices1;
    private List<Service> services;
    TextView Title;
    String role,name,email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_service_to_employee_profile);

        role = getIntent().getExtras().getString("role");
        name = getIntent().getExtras().getString("userName");
        email = getIntent().getExtras().getString("email");

        listViewServices1= (ListView)  findViewById(R.id.listViewServices2);

        Title = (TextView) findViewById(R.id.textView4);

        listViewServices1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                Service service = services.get(i);
                addServiceToEmployeeProfile2(service.getServiceName(), service.getEmployeeRole());
                return true;
            }
        });
    }


    @Override
    protected void onStart() {
        super.onStart();

        DBHelper dbServices = new DBHelper(this);
        services=dbServices.getAllServices();

        //creating adapter
        ServiceList serviceAdapter = new ServiceList(AddServiceToEmployeeProfile.this, services);

        //attaching adapter to the listview
        listViewServices1.setAdapter(serviceAdapter);
    }



    public void addServiceToEmployeeProfile2(String serviceName , String emprole ){
        DBHelper db = new DBHelper(getApplicationContext());
        int userID = db.userID(this.email,this.role);
        int serviceID = db.getServiceID(serviceName,emprole);
        if(!db.serviceAlreadyInEmployeeProfile(userID,serviceID)){

            db.addServiceToEmployeeProfile(userID,serviceID);
            Toast.makeText(AddServiceToEmployeeProfile.this,"Service: "+serviceName+"\n Role: "+emprole+"\nHas been added to your profile",Toast.LENGTH_LONG).show();


        }
        else{
            Toast.makeText(AddServiceToEmployeeProfile.this,"Service: "+serviceName+"\n Role: "+emprole+"\nIs already part of your profile",Toast.LENGTH_LONG).show();
        }


    }


}

package com.example.walkinclinicsservicesapp;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class ScheduleList extends ArrayAdapter<WorkingHours> {

    private Activity context;
    List <WorkingHours> workingHours;

    public ScheduleList(Activity context, List<WorkingHours> wh) {
        super(context, R.layout.activity_schedule_list, wh);
        this.context = context;
        this.workingHours = wh;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();

        View listViewItem = inflater.inflate(R.layout.activity_schedule_list, null, true);

        TextView textViewDayName = (TextView) listViewItem.findViewById(R.id.textViewDayName);
        TextView textViewClinicName = (TextView) listViewItem.findViewById(R.id.textViewClinicName);
        TextView textViewClinicAddress= (TextView) listViewItem.findViewById(R.id.textViewClinicAddress);
        TextView textViewClinicPhoneNumber = (TextView) listViewItem.findViewById(R.id.textViewClinicPhoneNumber);
        TextView textViewClinicStart = (TextView) listViewItem.findViewById(R.id.textViewStart);
        TextView textViewClinicEnd= (TextView) listViewItem.findViewById(R.id.textViewEnd);

        WorkingHours wh= workingHours.get(position);

        textViewDayName.setText(wh.getDay());
        textViewClinicName.setText(wh.getClinic().getClinicName());
        textViewClinicAddress.setText(wh.getClinic().getAddress());
        textViewClinicPhoneNumber.setText(wh.getClinic().getPhoneNumber());
        String start="Start at: "+wh.getStartsWork();
        textViewClinicStart.setText(start);
        String end="End at: "+wh.getEndsWork();
        textViewClinicEnd.setText(end);

        return listViewItem;
    }


}

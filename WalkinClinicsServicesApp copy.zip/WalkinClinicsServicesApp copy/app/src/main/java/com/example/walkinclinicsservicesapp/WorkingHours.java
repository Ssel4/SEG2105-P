package com.example.walkinclinicsservicesapp;

public class    WorkingHours {

    private String monday,tuesday,wedneday,thursday,friday,saturday,sunday;

    private String start;
    private String end;
    private String day;

    private Clinic clinic;
    public WorkingHours (Clinic clinic, String day,String start, String end){
        this.clinic=clinic;
        this.day=day;
        this.start=start;
        this.end=end;
    }

    public Clinic getClinic(){
        return clinic;
    }

    public String getDay(){
        return day;
    }

    public String getStartsWork(){
        return start;
    }
    public String getEndsWork(){
        return end;
    }





}

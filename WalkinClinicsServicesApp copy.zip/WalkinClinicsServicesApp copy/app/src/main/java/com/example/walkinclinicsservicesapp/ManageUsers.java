package com.example.walkinclinicsservicesapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class ManageUsers extends AppCompatActivity {


    Button addServiceButton, addNewServiceButton;
    private ListView listViewUsers;
    private List<UserAccount> users;
    Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_users);




        listViewUsers= (ListView)  findViewById(R.id.listViewServices);

        spinner = (Spinner)findViewById(R.id.spinnerEmployeeRole);

        addServiceButton = (Button)findViewById(R.id.addServiceButton);


        listViewUsers.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                UserAccount userAccount = users.get(i);
                showDeleteDialog(userAccount.getName(), userAccount.getRole(),userAccount.getEmail(),userAccount.getId());
                return true;
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();

        DBHelper db= new DBHelper(this);
        users=db.getAllUsers();

        //creating adapter
        UserList userAdapter = new UserList(ManageUsers.this, users);

        //attaching adapter to the listview
        listViewUsers.setAdapter(userAdapter);
    }


    private void showDeleteDialog(final String name,final  String role,final String email, final String id){

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.layout_delete_service, null);
        dialogBuilder.setView(dialogView);

        final TextView textViewName = (TextView) dialogView.findViewById(R.id.textViewName2);
        textViewName.setText(name);
        textViewName.setVisibility(View.VISIBLE);
        final TextView textViewEmail = (TextView) dialogView.findViewById(R.id.textViewEmail2);
        textViewEmail.setText(email);
        textViewEmail.setVisibility(View.VISIBLE);
        final TextView textViewRole = (TextView)  dialogView.findViewById(R.id.textViewRole2);;
        textViewRole.setText(role);
        textViewRole.setVisibility(View.VISIBLE);
        final TextView textViewId = (TextView)  dialogView.findViewById(R.id.textViewId2);;
        textViewId.setText(id);
        textViewId.setVisibility(View.VISIBLE);

        final Button buttonUpdate = (Button) dialogView.findViewById(R.id.buttonUpdateService);
        final EditText editTextServiceName = (EditText) dialogView.findViewById(R.id.editTextServiceName);
        final EditText editTextRole  = (EditText) dialogView.findViewById(R.id.editTextRole);
        buttonUpdate.setVisibility(View.GONE);
        editTextServiceName.setVisibility(View.GONE);
        editTextRole.setVisibility(View.GONE);

        final Button buttonDelete = (Button) dialogView.findViewById(R.id.buttonDeleteService);

        final AlertDialog b = dialogBuilder.create();
        b.show();


        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelper db = new DBHelper(getApplicationContext());
                db.deleteUserAccount(name, role, email);
                b.dismiss();
                onStart();
                Toast.makeText(ManageUsers.this,"Account deleted.",Toast.LENGTH_SHORT).show();
            }
        });

    }

}

package com.example.walkinclinicsservicesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TimePicker;
import android.widget.Toast;
import java.util.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;


public class SearchServicePatient extends AppCompatActivity {

    String name,email,role;
    private List<Clinic> clinics;
    ListView listViewAllServices;
    Switch switch1, switch2,switch3,switch4;
    Button buttonSearch,editTextOpenSearch;
    TimePickerDialog timePickerDialogue;

    EditText editTextServiceSearch, editTextAddressSearch,editTextClinicNameSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_service_patient);

        role = getIntent().getExtras().getString("role");
        name = getIntent().getExtras().getString("userName");
        email = getIntent().getExtras().getString("email");

        editTextAddressSearch = (EditText) findViewById( R.id.editTextAddressSearch);
        editTextClinicNameSearch = (EditText) findViewById( R.id.editTextClinicNameSearch);
        editTextOpenSearch = (Button) findViewById(R.id.buttonIsOpenSearch);
        editTextOpenSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                timePickerDialogue =new TimePickerDialog(SearchServicePatient.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minute) {
                        editTextOpenSearch.setText(String.format("%02d:%02d",hourOfDay,minute));
                    }
                },00,00,true);
                timePickerDialogue.show();
            }
        });

        editTextServiceSearch = (EditText) findViewById(R.id.editTextServiceSearch);

        listViewAllServices = (ListView) findViewById(R.id.listViewAllServices);

        switch1 = (Switch) findViewById(R.id.switch1);
        switch2 = (Switch) findViewById(R.id.switch2);
        switch3 = (Switch) findViewById(R.id.switch3);
        switch4 = (Switch) findViewById(R.id.switch4);


        switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(switch1.isChecked()){
                    switch2.setChecked(false);
                    switch3.setChecked(false);
                    switch4.setChecked(false);

                    editTextAddressSearch.setVisibility(View.VISIBLE);
                    editTextClinicNameSearch.setVisibility(View.INVISIBLE);
                    editTextOpenSearch.setVisibility(View.INVISIBLE);
                    editTextServiceSearch.setVisibility(View.INVISIBLE);

                }
                else{
                    editTextAddressSearch.setVisibility(View.INVISIBLE);
                }
            }
        });

        switch2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(switch2.isChecked()){
                    switch1.setChecked(false);
                    switch3.setChecked(false);
                    switch4.setChecked(false);

                    editTextClinicNameSearch.setVisibility(View.VISIBLE);
                    editTextAddressSearch.setVisibility(View.INVISIBLE);
                    editTextOpenSearch.setVisibility(View.INVISIBLE);
                    editTextServiceSearch.setVisibility(View.INVISIBLE);
                }
                else{
                    editTextClinicNameSearch.setVisibility(View.INVISIBLE);
                }
            }
        });

        switch3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(switch3.isChecked()){
                    switch1.setChecked(false);
                    switch2.setChecked(false);
                    switch4.setChecked(false);

                    editTextClinicNameSearch.setVisibility(View.INVISIBLE);
                    editTextAddressSearch.setVisibility(View.INVISIBLE);
                    editTextOpenSearch.setVisibility(View.VISIBLE);
                    editTextServiceSearch.setVisibility(View.INVISIBLE);
                }
                else{
                    editTextOpenSearch.setVisibility(View.INVISIBLE);

                }
            }
        });

        switch4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(switch4.isChecked()){
                    switch1.setChecked(false);
                    switch2.setChecked(false);
                    switch3.setChecked(false);

                    editTextClinicNameSearch.setVisibility(View.INVISIBLE);
                    editTextAddressSearch.setVisibility(View.INVISIBLE);
                    editTextOpenSearch.setVisibility(View.INVISIBLE);
                    editTextServiceSearch.setVisibility(View.VISIBLE);
                }
                else{
                    editTextServiceSearch.setVisibility(View.INVISIBLE);
                }
            }
        });

        buttonSearch = (Button) findViewById(R.id.buttonSearch);



        listViewAllServices.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {


                Clinic clinic= clinics.get(i);
                Bundle bundle = new Bundle();
                bundle.putString("userName",name);
                bundle.putString("role",role);
                bundle.putString("email",email);
                bundle.putString("clinic",clinic.getClinicName());
                bundle.putString("address",clinic.getAddress());
                bundle.putString("phone",clinic.getPhoneNumber());



                Intent intentPatient = new Intent(getApplicationContext(), ClinicProfile.class);
                intentPatient.putExtras(bundle);
                startActivityForResult(intentPatient, 0);
                return true;
            }
        });

    }


    @Override
    protected void onStart() {
        super.onStart();


        DBHelper db = new DBHelper(this);
        clinics=db.getAllClinicsThatOfferServices();

        //creating adapter
        ClinicRatingList clinicAdapter = new ClinicRatingList(SearchServicePatient.this, clinics);

        listViewAllServices.setAdapter(clinicAdapter);
    }



    public ClinicRatingList getAdapter(){
        DBHelper db = new DBHelper(this);
        ClinicRatingList clinicAdapter ;
        List<Clinic> tmp = db.getAllClinicsThatOfferServices();

        if(switch1.isChecked()){
            if(editTextAddressSearch.getText().toString().isEmpty()){
                tmp=db.getAllClinicsThatOfferServices();
                Toast.makeText(SearchServicePatient.this,"Showing all Clinics.",Toast.LENGTH_SHORT).show();

            }
            else {
                tmp = db.customSearchByClinicAddress(editTextAddressSearch.getText().toString());
                Toast.makeText(SearchServicePatient.this,"Custom Search by address.",Toast.LENGTH_SHORT).show();

            }
        }

        else if(switch2.isChecked()){
            if(editTextClinicNameSearch.getText().toString().isEmpty() ){
                tmp=db.getAllClinicsThatOfferServices();
                Toast.makeText(SearchServicePatient.this,"Showing all Clinics.",Toast.LENGTH_SHORT).show();

            }
            else{
                tmp=db.customSearchByClinicName(editTextClinicNameSearch.getText().toString());
                Toast.makeText(SearchServicePatient.this,"Custom Search by clinic name.",Toast.LENGTH_SHORT).show();

            }
        }

        else if(switch3.isChecked()){
             if(editTextOpenSearch.getText().toString().isEmpty() || editTextOpenSearch.getText().toString().equals("Is Open At")){
                 tmp=db.getAllClinicsThatOfferServices();
                 Toast.makeText(SearchServicePatient.this,"Showing all Clinics.",Toast.LENGTH_SHORT).show();

             }
             else{
                 tmp=db.customSearchByClinicOpenAt(editTextOpenSearch.getText().toString());
                 Toast.makeText(SearchServicePatient.this,"Custom Search by open hours.",Toast.LENGTH_SHORT).show();

             }

        }
        else if(switch4.isChecked()){
            if( editTextServiceSearch.getText().toString().isEmpty()){
                tmp=db.getAllClinicsThatOfferServices();
                Toast.makeText(SearchServicePatient.this,"Showing all Clinics.",Toast.LENGTH_SHORT).show();

            }
            else{
                tmp=db.customSearchOfClinicsByService(editTextServiceSearch.getText().toString());
                Toast.makeText(SearchServicePatient.this,"Custom Search by services offered at clinic.",Toast.LENGTH_SHORT).show();

            }
        }

        else {
            tmp=db.getAllClinicsThatOfferServices();
        }
        clinicAdapter = new ClinicRatingList(SearchServicePatient.this, tmp);
        return clinicAdapter;
    }


    public void search(View view){
        if(switch1.isChecked() || switch2.isChecked() || switch3.isChecked() || switch4.isChecked()){
            listViewAllServices.setAdapter(getAdapter());
        }
        else{
            Toast.makeText(SearchServicePatient.this,"Showing all Clinics.",Toast.LENGTH_SHORT).show();
            listViewAllServices.setAdapter(getAdapter());
        }
    }


}

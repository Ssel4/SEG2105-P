package com.example.walkinclinicsservicesapp;

public class Clinic {

    private String clinicName, address, phoneNumber,opensAt,closesAt;
    private int nbOfRatings, sumOfAllRatings;

    public Clinic (String clinicName, String phoneNumber, String address, String opensAt, String closesAt){
        this.clinicName=clinicName;
        this.address=address;
        this.phoneNumber=phoneNumber;
        this.opensAt=opensAt;
        this.closesAt=closesAt;
        this.nbOfRatings=0;
        this.sumOfAllRatings=0;
    }

    public Clinic (String clinicName, String phoneNumber, String address, String opensAt, String closesAt,int sumOfAllRatings ,int nbOfRatings){
        this.clinicName=clinicName;
        this.address=address;
        this.phoneNumber=phoneNumber;
        this.opensAt=opensAt;
        this.closesAt=closesAt;
        this.nbOfRatings=nbOfRatings;
        this.sumOfAllRatings=sumOfAllRatings;
    }

//getters
    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getClinicName() {
        return clinicName;
    }
    public String getAddress(){
        return address;
    }


    public String getOpensAt(){
        return opensAt;
    }
    public String getClosesAt(){
        return closesAt;
    }

    public int getNbOfRatings(){
        return nbOfRatings;
    }

    public int getSumOfAllRatings(){
        return sumOfAllRatings;
    }

//setters
    public void setPhoneNumber(String newNumber){
        this.phoneNumber=newNumber;
    }

    public void setClinicName(String newName){
        this.clinicName=newName;
    }

    public void setAddress(String newAddress){
        this.address=newAddress;
    }

    public  void setNbOfRatings(int a){
        nbOfRatings=a;
    }
    public void incrementNbOfRating(){
        nbOfRatings++;
    }

    public void setSumOfAllRatings(int a){
        sumOfAllRatings=a;
    }

    public void addToSumOfAllRAting(int a){
        sumOfAllRatings=+a;
    }

    public int getRating(){

        if(getNbOfRatings()==0 || getSumOfAllRatings()==0){
            return 0;
        }

        return getSumOfAllRatings()/getSumOfAllRatings();
    }


}

package com.example.walkinclinicsservicesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

public class ClinicProfile extends AppCompatActivity {

    String role,name,email,clinicName,clinicAddress,clinicPhone;
    Clinic clinic;
    int rating;
    TextView clinicNameText,ClinicAddress,ClinicPhoneNumber,openTime,closeTime;
    Button book;
    RatingBar ratingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clinic_profile);

        DBHelper db = new DBHelper(this);


        role = getIntent().getExtras().getString("role");
        name = getIntent().getExtras().getString("userName");
        email = getIntent().getExtras().getString("email");
        clinicName= getIntent().getExtras().getString("clinic");
        clinicAddress = getIntent().getExtras().getString("address");
        clinicPhone = getIntent().getExtras().getString("phone");
        clinic = db.getClinic(clinicName,clinicAddress,clinicPhone);



        clinicNameText = (TextView) findViewById(R.id.clinicName);
        clinicNameText.setText(clinic.getClinicName());
        ClinicAddress = (TextView) findViewById(R.id.ClinicAddress);
        ClinicAddress.setText(clinic.getAddress());
        ClinicPhoneNumber = (TextView) findViewById(R.id.ClinicPhoneNumber);
        ClinicPhoneNumber.setText(clinic.getPhoneNumber());
        openTime = (TextView) findViewById(R.id.openTime);
        openTime.setText(clinic.getOpensAt());
        closeTime = (TextView) findViewById(R.id.closeTime);
        closeTime.setText(clinic.getClosesAt());
        ratingBar = (RatingBar) findViewById(R.id.ratingClinic);
        ratingBar.setIsIndicator(true);
        int sum = db.getRating( db.getClinicID(clinicName,clinicAddress,clinicPhone))[0];
        int num = db.getRating( db.getClinicID(clinicName,clinicAddress,clinicPhone))[1];
        int rate;
        if(sum==0 || num==0){
            rate=0;
        }
        else{
            rate = (sum/num);
        }
        ratingBar.setRating( rate);
        book = (Button) findViewById(R.id.book);
        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Bundle bundle = new Bundle();
                bundle.putString("userName",name);
                bundle.putString("role",role);
                bundle.putString("email",email);
                bundle.putString("clinic",clinic.getClinicName());
                bundle.putString("address",clinic.getAddress());
                bundle.putString("phone",clinic.getPhoneNumber());

                Intent intentPatient = new Intent(getApplicationContext(), BookAppointment.class);
                intentPatient.putExtras(bundle);
                startActivityForResult(intentPatient, 0);
                finish();
            }
        });





    }
}

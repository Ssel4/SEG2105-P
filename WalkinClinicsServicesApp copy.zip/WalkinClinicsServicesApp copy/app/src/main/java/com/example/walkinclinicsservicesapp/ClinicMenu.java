package com.example.walkinclinicsservicesapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class ClinicMenu extends AppCompatActivity {
    String role,name,email;
    ListView listViewClinics;
    List<Clinic> clinics;
    Button continueButtonSchedule2,continueToAddClinic;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clinic_menu);

        listViewClinics = (ListView)  findViewById(R.id.listViewEmployeeClinics);

        role = getIntent().getExtras().getString("role");
        name = getIntent().getExtras().getString("userName");
        email = getIntent().getExtras().getString("email");


        continueToAddClinic = (Button) findViewById(R.id.buttonAddClinic);
        setContinueToAddClinic();

        continueButtonSchedule2 = (Button) findViewById(R.id.buttonSchedule2);
        continueToCurrentSchedule();


        listViewClinics.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                Clinic clinic= clinics.get(i);
                showDeleteClinicFromEmployeeProfile(clinic.getClinicName(),clinic.getAddress(), clinic.getPhoneNumber());
                return true;
            }
        });


    }

    @Override
    protected void onStart() {
        super.onStart();

        DBHelper dbClinic = new DBHelper(this);
        clinics=dbClinic.getAllEmployeeClinics(email);



        //creating adapter
        ClinicList clinicAdapter = new ClinicList(ClinicMenu.this, clinics);

        //attaching adapter to the listview
        listViewClinics.setAdapter(clinicAdapter);
    }


    public void setContinueToAddClinic(){
        final Bundle bundle=new Bundle();
        bundle.putString("userName",name);
        bundle.putString("role",role);
        bundle.putString("email",email);

        continueToAddClinic.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent =  new Intent (getApplicationContext(), AddClinicToEmployeeProfile.class);//change
                intent.putExtras( bundle);
                startActivityForResult(intent,0);
            }
        });
    }



    public void continueToCurrentSchedule(){
        final Bundle bundle=new Bundle();
        bundle.putString("userName",name);
        bundle.putString("role",role);
        bundle.putString("email",email);

        continueButtonSchedule2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent =  new Intent (getApplicationContext(), Schedule.class);
                intent.putExtras( bundle);
                startActivityForResult(intent,0);
            }
        });
    }

    private void showDeleteClinicFromEmployeeProfile(final String clinicName, final String address, final String phoneNumber){

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.del_clinic_employee_dialogue, null);
        dialogBuilder.setView(dialogView);

        final TextView textViewClinicNameDel= (TextView) dialogView.findViewById(R.id.textViewClinicNameDel);
        textViewClinicNameDel.setText(clinicName);
        final TextView textViewAddressDel= (TextView) dialogView.findViewById(R.id.textViewAddressDel);
        textViewAddressDel.setText(address);
        final TextView textViewPhoneNumberDel= (TextView) dialogView.findViewById(R.id.textViewPhoneNumberDel);
        textViewPhoneNumberDel.setText(phoneNumber);
        final Button buttonDeleteClinic = (Button) dialogView.findViewById(R.id.buttonDeleteClinic);
        dialogBuilder.setTitle(clinicName);
        final AlertDialog b = dialogBuilder.create();
        b.show();

        buttonDeleteClinic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelper db = new DBHelper(getApplicationContext());
                db.removeClinicFromEmployeeProfile(db.userID(email,role), db.getClinicID(clinicName,address,phoneNumber));
                b.dismiss();
                onStart();
                Toast.makeText(ClinicMenu.this,"Service deleted.",Toast.LENGTH_SHORT).show();
            }
        });
    }

}

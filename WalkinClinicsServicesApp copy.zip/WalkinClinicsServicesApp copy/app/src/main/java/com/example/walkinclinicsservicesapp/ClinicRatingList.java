package com.example.walkinclinicsservicesapp;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;

import java.util.List;

import java.util.List;

public class ClinicRatingList extends ArrayAdapter<Clinic> {


    private Activity context;
    List <Clinic> clinics;
    RatingBar rating;

    public ClinicRatingList (Activity context, List<Clinic> clinics){
        super(context, R.layout.layout_clinic_service_list, clinics);
        this.clinics=clinics;
        this.context=context;
    }


    public View getView(int position, View convertView, ViewGroup parent) {
        DBHelper db = new DBHelper(getContext());

        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.layout_clinic_service_list, null, true);

        TextView textViewClinicName = (TextView) listViewItem.findViewById(R.id.textViewClinicName);
        rating =(RatingBar) listViewItem.findViewById(R.id.rating);


        Clinic clinic = clinics.get(position);
        int sum = db.getRating( db.getClinicID(clinic.getClinicName(),clinic.getAddress(),clinic.getPhoneNumber()))[0];
        int num = db.getRating( db.getClinicID(clinic.getClinicName(),clinic.getAddress(),clinic.getPhoneNumber()))[1];
        int rate;
        if(sum==0 || num==0){
            rate=0;
        }
        else{
            rate = (sum/num);
        }
        rating.setRating( rate);
        textViewClinicName.setText(clinic.getClinicName());

        return listViewItem;
    }

}

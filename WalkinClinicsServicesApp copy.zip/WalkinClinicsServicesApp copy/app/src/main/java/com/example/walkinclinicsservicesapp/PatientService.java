package com.example.walkinclinicsservicesapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class PatientService extends AppCompatActivity {

    Button addServiceButton;
    ListView listViewServices;
    List<Service> services;
    List<ClinicAppointment> clinics;
    TextView textView3;
    String name,email,role;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_service);

        role = getIntent().getExtras().getString("role");
        name = getIntent().getExtras().getString("userName");
        email = getIntent().getExtras().getString("email");

        listViewServices= (ListView)  findViewById(R.id.listViewEmployeeServices);

        textView3 = (TextView ) findViewById(R.id.textView3);
        textView3.setText("Appointments:");


        addServiceButton = (Button)findViewById(R.id.addServiceEmployeeButton);
        addServiceButton.setText("Add Appointment");
        addPatientService();

        listViewServices.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                ClinicAppointment clinicAppointment = clinics.get(i);
                showDeleteDialog(clinicAppointment);
                return true;
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();

        DBHelper db = new DBHelper(this);

        clinics=db.getClinicAppointmentList(db.userID(email,role));

        //creating adapter
        ClinicAppointmentList clinicAppointmentAdapter = new ClinicAppointmentList(PatientService.this,clinics);


        //attaching adapter to the listview
        listViewServices.setAdapter(clinicAppointmentAdapter);
    }

    public void addPatientService(){
        final Bundle bundle=new Bundle();
        bundle.putString("userName",name);
        bundle.putString("role",role);
        bundle.putString("email",email);


        addServiceButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), SearchServicePatient.class);
                intent.putExtras( bundle);
                startActivityForResult(intent, 0);
            }
        });
    }

    private void showDeleteDialog(final ClinicAppointment clinicAppointment){

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.del_service_employee_dialogue, null);
        dialogBuilder.setView(dialogView);


        final TextView TextClinicName = (TextView) dialogView.findViewById(R.id.textViewDelServiceNameEmployeeProfile);
        final TextView date1 = (TextView) dialogView.findViewById(R.id.date1);
        date1.setVisibility(View.VISIBLE);
        final TextView time1 = (TextView) dialogView.findViewById(R.id.time1);
        time1.setVisibility(View.VISIBLE);

        TextClinicName.setText(clinicAppointment.getName());
        date1.setText(clinicAppointment.getAppointmentDate());
        time1.setText(clinicAppointment.getAppointmentTime());

        final Button buttonDelete = (Button) dialogView.findViewById(R.id.buttonDelToEmployeeProfile);

        dialogBuilder.setTitle("Remove Appointment: ");
        final AlertDialog b = dialogBuilder.create();
        b.show();


        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelper db = new DBHelper(getApplicationContext());

                db.removeAppointment(db.getAppointmentID(db.userID(email,role), db.getClinicID(clinicAppointment.getName(),clinicAppointment.getAddress(),clinicAppointment.getPhone()),clinicAppointment.getAppointmentDate(),clinicAppointment.getAppointmentTime()));
                b.dismiss();
                onStart();
                Toast.makeText(PatientService.this,"Appointment removed.",Toast.LENGTH_SHORT).show();
            }
        });
    }



}
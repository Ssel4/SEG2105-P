package com.example.walkinclinicsservicesapp;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;

    public static final String DATABASE_NAME = "DB_version_18.db";

    public static final String TABLE_NAME = "Account_table";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "NAME";
    public static final String COL_3 = "EMAIL";
    public static final String COL_4 = "ROLE";
    public static final String COL_5 = " PASSWORD";
    public static final String DB_CREATE_ACCOUNT = "CREATE TABLE " + TABLE_NAME + "(" + COL_1 + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_2 + " TEXT, " + COL_3 + " TEXT, " + COL_4 + " TEXT, " + COL_5 + " TEXT" + ")";


    public static final String TABLE_SERVICE = "Services";
    public static final String SERVICE_COL_1 = "ID";
    public static final String SERVICE_COL_2 = "SERVICE";
    public static final String SERVICE_COL_3 = "ROLE";
    public static final String DB_CREATE_SERVICE = "CREATE TABLE " + TABLE_SERVICE + "(" + SERVICE_COL_1 + " INTEGER PRIMARY KEY AUTOINCREMENT, " + SERVICE_COL_2 + " TEXT, " + SERVICE_COL_3 + " TEXT " + ")";


    //DB_version_2
    public static final String TABLE_EMPLOYEE_SERVICE = "Employee_Services";
    public static final String EMP_SERVICE_COL_0 = "ID";
    public static final String EMP_SERVICE_COL_1 = "Employee_ID";
    public static final String EMP_SERVICE_COL_2 = "Service_ID";
    public static final String DB_CREATE_EMPLOYEE_SERVICE = "CREATE TABLE " + TABLE_EMPLOYEE_SERVICE + "(" + EMP_SERVICE_COL_0 + " INTEGER PRIMARY KEY AUTOINCREMENT, " + EMP_SERVICE_COL_1 + " INTEGER , " + EMP_SERVICE_COL_2 + " INTEGER " + ")";

/*
    //DB_version_11

    public static final String TABLE_PATIENT_SERVICE = "Patient_Services";
    public static final String P_SERVICE_COL_0 = "ID";
    public static final String P_SERVICE_COL_1 = "Patient_ID";
    public static final String P_SERVICE_COL_2 = "Service_ID";
    public static final String DB_CREATE_PATIENT_SERVICE = "CREATE TABLE " + TABLE_PATIENT_SERVICE + "(" + P_SERVICE_COL_0 + " INTEGER PRIMARY KEY AUTOINCREMENT, " + P_SERVICE_COL_1 + " INTEGER , " + P_SERVICE_COL_2 + " INTEGER " + ")";

*/
    //DB_version_17
    public static final String TABLE_PATIENT_APPOINTMENT= "Patient_APPOINTMENTS";
    public static final String PATIENT_APP_COL_0 = "ID";
    public static final String PATIENT_APP_COL_1 = "Patient_ID";
    public static final String PATIENT_APP_COL_2 = "Clinic_ID";
    public static final String PATIENT_APP_COL_3 = "Date";
    public static final String PATIENT_APP_COL_4  = "Time";
    public static final String DB_CREATE_PATIENT_APP = "CREATE TABLE " + TABLE_PATIENT_APPOINTMENT + "(" + PATIENT_APP_COL_0 + " INTEGER PRIMARY KEY AUTOINCREMENT, " + PATIENT_APP_COL_1 + " INTEGER, " + PATIENT_APP_COL_2 + " INTEGER, " + PATIENT_APP_COL_3 + " TEXT, " + PATIENT_APP_COL_4 + " TEXT" + ")";



    //DB_version_14
    public static final String TABLE_CLINICS = "Clinics";
    public static final String CLINIC_COL_0 = "ID";
    public static final String CLINIC_COL_1 = "Name";
    public static final String CLINIC_COL_2 = "Address";
    public static final String CLINIC_COL_3 = "Phone_Number";
    public static final String CLINIC_COL_4 = "Open_At";
    public static final String CLINIC_COL_5 = "Close_At";
    public static final String CLINIC_COL_6 = "SumOfAllRating";
    public static final String CLINIC_COL_7 = "nbOfRating";
    public static final String DB_CREATE_CLINICS = "CREATE TABLE " + TABLE_CLINICS + "(" + CLINIC_COL_0 + " INTEGER PRIMARY KEY AUTOINCREMENT, " + CLINIC_COL_1 + " TEXT , " + CLINIC_COL_2 + " TEXT , " + CLINIC_COL_3 + " TEXT , " + CLINIC_COL_4 + " TEXT , " + CLINIC_COL_5 + " TEXT , " + CLINIC_COL_6 + " INTEGER , " + CLINIC_COL_7 + " INTEGER " + ")";

    //DB_version_5
    /*
    public static final String TABLE_CLINICS_PAYMENT_METHOD = "Clinics_PM";
    public static final String CLINIC_PM_COL_0 = "ID";
    public static final String CLINIC_PM_COL_1 = "Clinic_ID";
    public static final String CLINIC_PM_COL_2 = "Payment_Method";
    public static final String DB_CREATE_PM_CLINICS = "CREATE TABLE " + TABLE_CLINICS_PAYMENT_METHOD + "(" + CLINIC_PM_COL_0 + " INTEGER PRIMARY KEY AUTOINCREMENT, " + CLINIC_PM_COL_1 + " INTEGER , " + CLINIC_PM_COL_2 + " TEXT " + ")";

     */

    //DB_version_8
    public static final String TABLE_EMPLOYEE_CLINIC = "Employee_Clinics";
    public static final String EMP_CLINIC_COL_0 = "ID";
    public static final String EMP_CLINIC_COL_1 = "Employee_ID";
    public static final String EMP_CLINIC_COL_2 = "Clinic_ID";
    public static final String EMP_CLINIC_COL_3 = "Day";
    public static final String EMP_CLINIC_COL_4 = "Start_Work";
    public static final String EMP_CLINIC_COL_5 = "End_Work";
    public static final String DB_CREATE_EMPLOYEE_CLINIC = "CREATE TABLE " + TABLE_EMPLOYEE_CLINIC + "(" + EMP_CLINIC_COL_0 + " INTEGER PRIMARY KEY AUTOINCREMENT, " + EMP_CLINIC_COL_1 + " INTEGER , " + EMP_CLINIC_COL_2 + " INTEGER , " + EMP_CLINIC_COL_3 + " TEXT , " + EMP_CLINIC_COL_4 + " TEXT , " + EMP_CLINIC_COL_5 + " TEXT  " + ")";


    //DB_version_15
    public static final String TABLE_CLINIC_SERVICES_EMPLOYEE = "Clinic_Services_Employee_IDs";
    public static final String CLINIC_SERVICES_0 = "ID";
    public static final String CLINIC_SERVICES_1 = "Clinic_ID";
    public static final String CLINIC_SERVICES_2 = "Service_ID";
    public static final String CLINIC_SERVICES_3 = "Employee_ID";
    public static final String DB_CREATE_CLINIC_SERVICES = "CREATE TABLE " + TABLE_CLINIC_SERVICES_EMPLOYEE + "(" + CLINIC_SERVICES_0 + " INTEGER PRIMARY KEY AUTOINCREMENT, " + CLINIC_SERVICES_1 + " INTEGER , " + CLINIC_SERVICES_2 + " INTEGER , " + CLINIC_SERVICES_3 + " INTEGER " + ")";


    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(DB_CREATE_ACCOUNT);
        db.execSQL(DB_CREATE_SERVICE);
        db.execSQL(DB_CREATE_EMPLOYEE_SERVICE);
        db.execSQL(DB_CREATE_CLINICS);
        db.execSQL(DB_CREATE_EMPLOYEE_CLINIC);
        db.execSQL(DB_CREATE_CLINIC_SERVICES);
        db.execSQL(DB_CREATE_PATIENT_APP);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SERVICE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EMPLOYEE_SERVICE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CLINICS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EMPLOYEE_CLINIC);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CLINIC_SERVICES_EMPLOYEE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PATIENT_APPOINTMENT);
        onCreate(db);
    }

    //add to 3id table
    ///////////

    public boolean addServiceToEmployeeProfile(int employeeID, int serviceID) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(EMP_SERVICE_COL_1, employeeID);
        contentValues.put(EMP_SERVICE_COL_2, serviceID);

        long alpha = db.insert(TABLE_EMPLOYEE_SERVICE, null, contentValues);

        String query = "SELECT DISTINCT Clinic_ID FROM "+TABLE_EMPLOYEE_CLINIC+" WHERE "+EMP_CLINIC_COL_1+" =\""+employeeID+"\"";
        Cursor result= db.rawQuery(query,null);
        if(result.getCount()>0){
            while(result.moveToNext()){
                ContentValues contentValues1 = new ContentValues();
                contentValues1.put(CLINIC_SERVICES_3,employeeID);
                contentValues1.put(CLINIC_SERVICES_2,serviceID);
                contentValues1.put(CLINIC_SERVICES_1,result.getInt(0));
                db.insert(TABLE_CLINIC_SERVICES_EMPLOYEE,null,contentValues1);
            }
        }


        db.close();
        if (alpha == -1) {
            return false;
        }
        return true;
    }

    public boolean addClinicToEmployeeProfile(int employeeID, int clinicID, String Day, String Start, String End) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(EMP_CLINIC_COL_1, employeeID);
        contentValues.put(EMP_CLINIC_COL_2, clinicID);
        contentValues.put(EMP_CLINIC_COL_3, Day);
        contentValues.put(EMP_CLINIC_COL_4, Start);
        contentValues.put(EMP_CLINIC_COL_5, End);
        long alpha = db.insert(TABLE_EMPLOYEE_CLINIC, null, contentValues);


        String query = "SELECT DISTINCT Service_ID FROM "+TABLE_EMPLOYEE_SERVICE+" WHERE "+EMP_SERVICE_COL_1+" =\""+employeeID+"\"";
        Cursor result= db.rawQuery(query,null);
        if(result.getCount()>0){
            while(result.moveToNext()){
                ContentValues contentValues1 = new ContentValues();
                contentValues1.put(CLINIC_SERVICES_3,employeeID);
                contentValues1.put(CLINIC_SERVICES_2,result.getInt(0));
                contentValues1.put(CLINIC_SERVICES_1,clinicID);
                db.insert(TABLE_CLINIC_SERVICES_EMPLOYEE,null,contentValues1);
            }
        }
        db.close();
        if (alpha == -1) {
            return false;
        }
        return true;
    }
/*
    public void addEmployeeServiceToClinic(int employeeID) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query1 = "Select DISTINCT Service_ID FROM " + TABLE_EMPLOYEE_SERVICE + " WHERE " + EMP_SERVICE_COL_1 + " =\"" + employeeID + "\"";
        Cursor result1 = db.rawQuery(query1, null);

        if (result1.getCount() > 0) {
            int[] servicesIDs = new int[result1.getCount() + 1];
            int i = 0;
            while (result1.moveToNext()) {
                servicesIDs[i++] = result1.getInt(2);
            }

            String query2 = "SELECT * FROM " + TABLE_EMPLOYEE_CLINIC + " WHERE " + EMP_CLINIC_COL_1 + " =\"" + employeeID + "\"";
            Cursor result2 = db.rawQuery(query2, null);

            if (result2.getCount() > 0) {
                int[] clinicIDs = new int[result2.getCount()];
                int j = 0;
                while (result2.moveToNext()) {
                    clinicIDs[j++] = result2.getInt(2);
                }

                for (int x = 0; x < result1.getCount(); x++) {
                    for (int z = 0; z < result2.getCount(); z++) {
                        ContentValues contentValues = new ContentValues();
                        contentValues.put(CLINIC_SERVICES_1, clinicIDs[z]);
                        contentValues.put(CLINIC_SERVICES_2, servicesIDs[x]);
                        contentValues.put(CLINIC_SERVICES_3, employeeID);
                        db.insert(TABLE_CLINIC_SERVICES_EMPLOYEE, null, contentValues);
                    }
                }
            }
        }
        db.close();
    }

 */

    //////////


    //Get

    public String getUserName(int id){
        String name="";
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select ID FROM " + TABLE_NAME + " WHERE " + COL_1 + " =\"" + id + "\"";

        Cursor result = db.rawQuery(query, null);
        if (result.moveToFirst()) {
            name = result.getString(1);
        }
        return name;
    }

    public int userID(String email, String role) {
        int id = -1;
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select ID FROM " + TABLE_NAME + " WHERE " + COL_3 + " =\"" + email + "\" AND " + COL_4 + " =\"" + role + "\" ";

        Cursor result = db.rawQuery(query, null);

        if (result.moveToFirst()) {
            id = result.getInt(result.getColumnIndex("ID"));
        }
        return id;
    }
    //



    public boolean createAccount(String name, String email, String role, String password) {

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2, name);
        contentValues.put(COL_3, email);
        contentValues.put(COL_4, role);
        contentValues.put(COL_5, password);

        long alpha = sqLiteDatabase.insert(TABLE_NAME, null, contentValues);

        sqLiteDatabase.close();

        if (alpha == -1) {
            return false;
        }
        return true;
    }


    public boolean emailExist(String email, String role) {

        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
//EMAIL like '%"+email+"%'";
        String query = "Select * FROM " + TABLE_NAME + " WHERE EMAIL like '%" + email + "%' AND ROLE like '%" + role + "%' ";
        Cursor result = sqLiteDatabase.rawQuery(query, null);


        if (result.getCount() > 0) {
            sqLiteDatabase.close();
            return true;
        }
        sqLiteDatabase.close();
        return false;
    }


    public boolean logInAccount(String name, String email, String role, String password) {

        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        String query = "Select * FROM " + TABLE_NAME + " WHERE NAME like '%" + name + "%' AND EMAIL like '%" + email + "%' AND ROLE like '%" + role + "%'";
        Cursor result = sqLiteDatabase.rawQuery(query, null);

        boolean correctName = false;
        boolean correctEmail = false;
        boolean correctPassword = false;
        boolean correctRole = false;

        if (result.getCount() > 0) {
            while (result.moveToNext()) {

                if (result.getString(1).equalsIgnoreCase(name)) {
                    correctName = true;
                }
                if (result.getString(2).equalsIgnoreCase(email)) {
                    correctEmail = true;
                }
                if (result.getString(3).equalsIgnoreCase(role)) {
                    correctPassword = true;
                }
                if (result.getString(4).equalsIgnoreCase(password)) {
                    correctRole = true;
                }
            }
        }
        sqLiteDatabase.close();
        return (correctName && correctEmail && correctPassword && correctRole);
    }


    public boolean createService(String serviceName, String role) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(SERVICE_COL_2, serviceName);
        contentValues.put(SERVICE_COL_3, role);
        long alpha = db.insert(TABLE_SERVICE, null, contentValues);
        db.close();
        if (alpha == -1) {
            return false;
        }
        return true;
    }

    public List<Service> getAllServices() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select * FROM " + TABLE_SERVICE;
        Cursor result = db.rawQuery(query, null);
        List<Service> services = new ArrayList<>();

        if (result.getCount() > 0) {
            while (result.moveToNext()) {
                Service tmp = new Service(result.getString(1), result.getString(2));
                services.add(tmp);
            }
        }
        result.close();
        db.close();
        return services;
    }

    public List<UserAccount> getAllUsers() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select * FROM " + TABLE_NAME;
        Cursor result = db.rawQuery(query, null);
        List<UserAccount> userAccounts = new ArrayList<>();

        if (result.getCount() > 0) {
            while (result.moveToNext()) {
                UserAccount tmp = new UserAccount(result.getString(1),result.getString(2),result.getString(3),result.getInt(0));
                userAccounts.add(tmp);
            }
        }
        result.close();
        db.close();
        return userAccounts;
    }



    public void deleteUserAccount(String name, String role,String email) {

        SQLiteDatabase db = this.getWritableDatabase();
        String query = "Select * FROM " + TABLE_NAME + " WHERE " + COL_2 + " =\"" + name + "\" AND " + COL_4 + " =\"" + role + "\" AND "+COL_3+" =\"" +email+"\" ";
        Cursor result = db.rawQuery(query, null);
        if (result.moveToFirst()) {
            int idString = result.getInt(0);
            db.delete(TABLE_NAME, COL_1 + " = " + idString, null);


            if(role=="Employee"){
                String query2 = "SELECT * FROM "+TABLE_EMPLOYEE_SERVICE+" WHERE "+EMP_SERVICE_COL_1+" =\""+result.getInt(0)+"\"";
                Cursor result2= db.rawQuery(query2,null);
                if(result2.getCount()>0){
                    db.delete(TABLE_EMPLOYEE_SERVICE,EMP_SERVICE_COL_1 + " = "+idString,null);
                }
                String query3 = "SELECT * FROM "+TABLE_CLINIC_SERVICES_EMPLOYEE+" WHERE "+CLINIC_SERVICES_2+" =\" "+result.getInt(0)+"\"";
                Cursor result3= db.rawQuery(query3,null);
                if(result3.getCount()>0){
                    db.delete(TABLE_CLINIC_SERVICES_EMPLOYEE,CLINIC_SERVICES_2+" = "+idString,null);
                }
            }
            else if(role=="Patient"){

                String query2 = "SELECT * FROM "+TABLE_PATIENT_APPOINTMENT+" WHERE "+PATIENT_APP_COL_1+" =\""+result.getInt(0)+"\"";
                Cursor result2= db.rawQuery(query2,null);
                if(result2.getCount()>0){
                    db.delete(TABLE_PATIENT_APPOINTMENT,PATIENT_APP_COL_1 + " = "+idString,null);
                }
            }

        }
        db.close();
    }

    public void deleteService(String serviceName, String role) {

        SQLiteDatabase db = this.getWritableDatabase();
        String query = "Select * FROM " + TABLE_SERVICE + " WHERE " + SERVICE_COL_2 + " =\"" + serviceName + "\" AND " + SERVICE_COL_3 + " =\"" + role + "\" ";
        Cursor result = db.rawQuery(query, null);
        if (result.moveToFirst()) {
            int idString = result.getInt(0);
            db.delete(TABLE_SERVICE, SERVICE_COL_1 + " = " + idString, null);


            String query2 = "SELECT * FROM "+TABLE_EMPLOYEE_SERVICE+" WHERE "+EMP_SERVICE_COL_2+" =\""+result.getInt(0)+"\"";
            Cursor result2= db.rawQuery(query2,null);
            if(result2.getCount()>0){
                db.delete(TABLE_EMPLOYEE_SERVICE,EMP_SERVICE_COL_2 + " = "+idString,null);
            }
            String query3 = "SELECT * FROM "+TABLE_CLINIC_SERVICES_EMPLOYEE+" WHERE "+CLINIC_SERVICES_2+" =\" "+result.getInt(0)+"\"";
            Cursor result3= db.rawQuery(query3,null);
            if(result3.getCount()>0){
                db.delete(TABLE_CLINIC_SERVICES_EMPLOYEE,CLINIC_SERVICES_2+" = "+idString,null);
            }
        }
        db.close();
    }


    public void updateService(String serviceName1, String role1, String serviceName2, String role2) {

        SQLiteDatabase db = this.getWritableDatabase();
        String query1 = "Select * FROM " + TABLE_SERVICE + " WHERE " + SERVICE_COL_2 + " =\"" + serviceName1 + "\" AND " + SERVICE_COL_3 + " =\"" + role1 + "\"";
        Cursor result = db.rawQuery(query1, null);

        if (result.moveToFirst()) {
            String idString = result.getString(0);
            ContentValues cv = new ContentValues();
            cv.put(SERVICE_COL_2, serviceName2);
            cv.put(SERVICE_COL_3, role2);
            db.update(TABLE_SERVICE, cv, "ID=" + idString, null);
        }
        db.close();
    }


    //returns the list of services the employee has added to his profile
    public List<Service> getAllEmployeeServices(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<Service> services = new ArrayList<>();
        int id = this.userID(email, "Employee");
        if (id == -1) {
            return services;
        }
        String query = "Select * FROM " + TABLE_EMPLOYEE_SERVICE + " WHERE " + EMP_SERVICE_COL_1 + " =\"" + id + "\" ";
        Cursor result = db.rawQuery(query, null);

        if (result.getCount() > 0) {
            String tmp;
            result.moveToFirst();
            tmp = "(" + result.getInt(2);
            while (result.moveToNext()) {
                tmp = tmp + ", " + (result.getInt(2));
            }
            tmp = tmp + " )";
            String query2 = "Select * FROM " + TABLE_SERVICE + " WHERE " + SERVICE_COL_1 + " IN " + tmp;
            Cursor serviceResult = db.rawQuery(query2, null);
            if (serviceResult.getCount() > 0) {
                while (serviceResult.moveToNext()) {
                    Service service = new Service(serviceResult.getString(1), serviceResult.getString(2));
                    services.add(service);
                }
            }
            serviceResult.close();
        }
        result.close();
        db.close();
        return services;
    }

/*
    public List<Service> getAllPatientServices(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<Service> services = new ArrayList<>();
        int id = this.userID(email, "Patient");
        if (id == -1) {
            return services;
        }
        String query = "Select * FROM " + TABLE_PATIENT_SERVICE + " WHERE " + P_SERVICE_COL_1 + " =\"" + id + "\" ";
        Cursor result = db.rawQuery(query, null);

        if (result.getCount() > 0) {
            String tmp;
            result.moveToFirst();
            tmp = "(" + result.getInt(2);
            while (result.moveToNext()) {
                tmp = tmp + ", " + (result.getInt(2));
            }
            tmp = tmp + " )";
            String query2 = "Select * FROM " + TABLE_SERVICE + " WHERE " + SERVICE_COL_1 + " IN " + tmp;
            Cursor serviceResult = db.rawQuery(query2, null);
            if (serviceResult.getCount() > 0) {
                while (serviceResult.moveToNext()) {
                    Service service = new Service(serviceResult.getString(1), serviceResult.getString(2));
                    services.add(service);
                }
            }
            serviceResult.close();
        }
        result.close();
        db.close();
        return services;
    }

 */


    public int getServiceID(String name, String role) {
        int id = -1;
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select ID FROM " + TABLE_SERVICE + " WHERE " + SERVICE_COL_2 + " =\"" + name + "\" AND " + SERVICE_COL_3 + " =\"" + role + "\" ";
        Cursor result = db.rawQuery(query, null);

        if (result.moveToFirst()) {
            id = result.getInt(result.getColumnIndex("ID"));
        }
        return id;
    }


    public boolean serviceAlreadyInEmployeeProfile(int employeeID, int serviceID) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_EMPLOYEE_SERVICE + " WHERE " + EMP_SERVICE_COL_1 + " =\"" + employeeID + "\" AND " + EMP_SERVICE_COL_2 + " =\"" + serviceID + "\"";
        Cursor result = db.rawQuery(query, null);
        return result.getCount() > 0;
    }


    public boolean removeServiceFromEmployeeProfile(int employeeID, int serviceID) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "Select * FROM " + TABLE_EMPLOYEE_SERVICE + " WHERE " + EMP_SERVICE_COL_1 + " =\"" + employeeID + "\" AND " + EMP_SERVICE_COL_2 + " =\"" + serviceID + "\" ";
        Cursor result = db.rawQuery(query, null);
        if (result.moveToFirst()) {
            String idString = result.getString(0);
            db.delete(TABLE_EMPLOYEE_SERVICE, EMP_SERVICE_COL_0 + " = " + idString, null);
            return true;
        }
        return false;
    }


    //returns the list of clinics the employee has added to his profile
    public List<Clinic> getAllEmployeeClinics(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<Clinic> clinics = new ArrayList<>();
        int id = this.userID(email, "Employee");
        if (id == -1) {
            return clinics;
        }
        String query = "Select * FROM " + TABLE_EMPLOYEE_CLINIC + " WHERE " + EMP_CLINIC_COL_1 + " =\"" + id + "\" ";
        Cursor result = db.rawQuery(query, null);

        if (result.getCount() > 0) {
            String tmp;
            result.moveToFirst();
            tmp = "(" + result.getInt(2);
            while (result.moveToNext()) {
                tmp = tmp + ", " + (result.getInt(2));
            }
            tmp = tmp + " )";
            String query2 = "Select * FROM " + TABLE_CLINICS + " WHERE " + CLINIC_COL_0 + " IN " + tmp;
            Cursor clinicResult = db.rawQuery(query2, null);
            if (clinicResult.getCount() > 0) {
                while (clinicResult.moveToNext()) {
                    Clinic clinic = new Clinic(clinicResult.getString(1), clinicResult.getString(3), clinicResult.getString(2), clinicResult.getString(4), clinicResult.getString(5));
                    clinics.add(clinic);
                }
            }
            clinicResult.close();
        }
        result.close();

        db.close();
        return clinics;
    }


    //Clinics methods


    public boolean createClinic(String clinicName, String address, String phoneNumber, String OpensAt, String ClosesAt) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(CLINIC_COL_1, clinicName);
        contentValues.put(CLINIC_COL_2, address);
        contentValues.put(CLINIC_COL_3, phoneNumber);
        contentValues.put(CLINIC_COL_4, OpensAt);
        contentValues.put(CLINIC_COL_5, ClosesAt);
        contentValues.put(CLINIC_COL_6,0);
        contentValues.put(CLINIC_COL_7,0);
        long alpha = db.insert(TABLE_CLINICS, null, contentValues);
        db.close();
        if (alpha == -1) {
            return false;
        }
        return true;
    }

    public void deleteClinic(String clinicName, String address, String phoneNumber, String opensAt, String closesAt) {

        SQLiteDatabase db = this.getWritableDatabase();
        String query = "Select * FROM " + TABLE_CLINICS + " WHERE " + CLINIC_COL_1 + " =\"" + clinicName + "\" AND " + CLINIC_COL_2 + " =\"" + address + "\" AND " + CLINIC_COL_3 + " =\"" + phoneNumber + "\" AND " + CLINIC_COL_4 + " =\"" + opensAt + "\" AND " + CLINIC_COL_5 + " =\"" + closesAt + "\" ";

        Cursor result = db.rawQuery(query, null);
        if (result.moveToFirst()) {
            String idString = result.getString(0);
            db.delete(TABLE_CLINICS, CLINIC_COL_0 + " = " + idString, null);
        }
        result.close();
        db.close();
    }

    public List<Clinic> getAllClinics() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select * FROM " + TABLE_CLINICS;
        Cursor result = db.rawQuery(query, null);
        List<Clinic> clinics = new ArrayList<>();

        if (result.getCount() > 0) {
            while (result.moveToNext()) {
                Clinic clinic = new Clinic(result.getString(1), result.getString(3), result.getString(2), result.getString(4), result.getString(5));
                clinics.add(clinic);
            }
        }
        result.close();
        db.close();
        return clinics;
    }

    public int getClinicID(String clinicName, String address, String phoneNumber) {

        int id = -1;
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select * FROM " + TABLE_CLINICS + " WHERE " + CLINIC_COL_1 + " =\"" + clinicName + "\" AND " + CLINIC_COL_2 + " =\"" + address + "\" AND " + CLINIC_COL_3 + " =\"" + phoneNumber + "\" ";
        Cursor result = db.rawQuery(query, null);

        if (result.moveToFirst()) {
            id = result.getInt(result.getColumnIndex("ID"));
        }
        return id;

    }


    public boolean updateClinicToEmployeeProfile(int employeeID, int clinicID, String DayToBeChanged, String newDay, String Start, String End) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(EMP_CLINIC_COL_3, newDay);
        contentValues.put(EMP_CLINIC_COL_4, Start);
        contentValues.put(EMP_CLINIC_COL_5, End);
        int id=getEmployeeClinicID(employeeID,clinicID,DayToBeChanged);
        long alpha = db.update(TABLE_EMPLOYEE_CLINIC, contentValues, "ID=" + id , null);
        if (alpha == -1) {
            return false;
        }
        return true;
    }

    public int getEmployeeClinicID(int employeeID, int clinicID, String day){
        int id=-1;
        SQLiteDatabase db = this.getReadableDatabase();
        String query ="SELECT ID FROM "+TABLE_EMPLOYEE_CLINIC+" WHERE "+EMP_CLINIC_COL_1+" =\""+employeeID+"\" AND "+EMP_CLINIC_COL_2+" =\""+clinicID+"\" AND "+EMP_CLINIC_COL_3+" =\""+day+"\"";
        Cursor result = db.rawQuery(query,null);
        if(result.moveToFirst()){
            id=result.getInt(0);
        }
        return id;
    }

    public boolean alreadyWorkingThatDay(int employeeID, String day) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_EMPLOYEE_CLINIC + " WHERE " + EMP_CLINIC_COL_1 + " =\"" + employeeID + "\" AND " + EMP_CLINIC_COL_3 + " =\"" + day + "\"";
        Cursor result = db.rawQuery(query, null);
        return result.getCount() > 0;
    }

    public boolean updateAlreadyWorkingThatDay(int employeeID, String day) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_EMPLOYEE_CLINIC + " WHERE " + EMP_CLINIC_COL_1 + " =\"" + employeeID + "\" AND " + EMP_CLINIC_COL_3 + " =\"" + day + "\"";
        Cursor result = db.rawQuery(query, null);
        //
        if(result.moveToFirst()){
            String tmp =result.getString(3);
            if(tmp.equals(day)){
                return false;
            }
        }
        //
        return result.getCount() > 0;
    }

    public boolean removeClinicFromEmployeeProfile(int employeeID, int clinicID) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "Select * FROM " + TABLE_EMPLOYEE_CLINIC + " WHERE " + EMP_CLINIC_COL_1 + " =\"" + employeeID + "\" AND " + EMP_CLINIC_COL_2 + " =\"" + clinicID + "\" ";
        Cursor result = db.rawQuery(query, null);
        if (result.getCount() > 0) {
            while (result.moveToNext()) {
                String idString = result.getString(0);
                db.delete(TABLE_EMPLOYEE_CLINIC, EMP_CLINIC_COL_0 + " = " + idString, null);
            }
            return true;
        }
        return false;
    }


    //Schedule
    public String getClinicNameForDay(int employeeID, String day) {
        String name = "";
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_EMPLOYEE_CLINIC + " WHERE " + EMP_CLINIC_COL_1 + " =\"" + employeeID + "\" AND " + EMP_CLINIC_COL_3 + " =\"" + day + "\"";
        Cursor result = db.rawQuery(query, null);

        if (result.getCount() > 0) {
            result.moveToFirst();
            int clinicID = result.getInt(2);
            String tmp = String.valueOf(clinicID);
            String query2 = "SELECT * FROM " + TABLE_CLINICS + " WHERE " + CLINIC_COL_0 + " =\"" + tmp + "\"";
            Cursor clinicResult = db.rawQuery(query2, null);
            if (clinicResult.moveToFirst()) {
                name = clinicResult.getString(1);
            }
        }
        return name;
    }


    public String getClinicAddressForDay(int employeeID, String day) {
        String address = "";
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_EMPLOYEE_CLINIC + " WHERE " + EMP_CLINIC_COL_1 + " =\"" + employeeID + "\" AND " + EMP_CLINIC_COL_3 + " =\"" + day + "\"";
        Cursor result = db.rawQuery(query, null);

        if (result.getCount() > 0) {
            result.moveToFirst();
            int clinicID = result.getInt(2);
            String tmp = String.valueOf(clinicID);
            String query2 = "SELECT * FROM " + TABLE_CLINICS + " WHERE " + CLINIC_COL_0 + " =\"" + tmp + "\"";
            Cursor clinicResult = db.rawQuery(query2, null);
            if (clinicResult.moveToFirst()) {
                address = clinicResult.getString(2);
            }
        }
        return address;
    }

    public String getClinicPhoneNumber(int employeeID, String day) {
        String phone = "";
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_EMPLOYEE_CLINIC + " WHERE " + EMP_CLINIC_COL_1 + " =\"" + employeeID + "\" AND " + EMP_CLINIC_COL_3 + " =\"" + day + "\"";
        Cursor result = db.rawQuery(query, null);

        if (result.getCount() > 0) {
            result.moveToFirst();
            int clinicID = result.getInt(2);
            String tmp = String.valueOf(clinicID);
            String query2 = "SELECT * FROM " + TABLE_CLINICS + " WHERE " + CLINIC_COL_0 + " =\"" + tmp + "\"";
            Cursor clinicResult = db.rawQuery(query2, null);
            if (clinicResult.moveToFirst()) {
                phone = clinicResult.getString(3);
            }
        }
        return phone;
    }

    public String getEmployeeStartTime(int employeeID, String day) {
        String start = "";
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_EMPLOYEE_CLINIC + " WHERE " + EMP_CLINIC_COL_1 + " =\"" + employeeID + "\" AND " + EMP_CLINIC_COL_3 + " =\"" + day + "\"";
        Cursor result = db.rawQuery(query, null);
        if (result.getCount() > 0) {
            result.moveToFirst();
            start = result.getString(4);
        }
        return start;
    }

    public String getEmployeeEndTime(int employeeID, String day) {
        String end = "";
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_EMPLOYEE_CLINIC + " WHERE " + EMP_CLINIC_COL_1 + " =\"" + employeeID + "\" AND " + EMP_CLINIC_COL_3 + " =\"" + day + "\"";
        Cursor result = db.rawQuery(query, null);
        if (result.getCount() > 0) {
            result.moveToFirst();
            end = result.getString(5);
        }
        return end;
    }

    public boolean hasWork(int employeeID, String day) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_EMPLOYEE_CLINIC + " WHERE " + EMP_CLINIC_COL_1 + " =\"" + employeeID + "\" AND " + EMP_CLINIC_COL_3 + " =\"" + day + "\"";
        Cursor result = db.rawQuery(query, null);
        return result.getCount() > 0;
    }

    public List<WorkingHours> getAllEmployeeWorkHours(String employeeEmail) {

        List<WorkingHours> workingHoursList = new ArrayList<>();

        String[] Day = new String[]{"monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"};
        int id = this.userID(employeeEmail, "Employee");


        for (int i = 0; i < 7; i++) {
            if (this.hasWork(id, Day[i])) {
                Clinic clinic = new Clinic(getClinicNameForDay(id, Day[i]), getClinicPhoneNumber(id, Day[i]), getClinicAddressForDay(id, Day[i]), getClinicOpenTime(id, Day[i]), getClinicCloseTime(id, Day[i]));
                WorkingHours workingHours = new WorkingHours(clinic, Day[i], getEmployeeStartTime(id, Day[i]), getEmployeeEndTime(id, Day[i]));
                workingHoursList.add(workingHours);
            }
        }
        return workingHoursList;
    }

    public void deleteWorkingHourAndClinicFromEmployeeProfile(int employeeID, int clinicID, String day) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "Select * FROM " + TABLE_EMPLOYEE_CLINIC + " WHERE " + EMP_CLINIC_COL_1 + " =\"" + employeeID + "\" AND " + EMP_CLINIC_COL_2 + " =\"" + clinicID + "\" AND " + EMP_CLINIC_COL_3 + " =\"" + day + "\" ";
        Cursor result = db.rawQuery(query, null);
        if (result.moveToFirst()) {
            String idString = result.getString(0);
            db.delete(TABLE_EMPLOYEE_CLINIC, EMP_CLINIC_COL_0 + " = " + idString, null);
        }
        db.close();
    }

    public String getClinicOpenTime(int employeeID, String day) {
        String start = "";
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_EMPLOYEE_CLINIC + " WHERE " + EMP_CLINIC_COL_1 + " =\"" + employeeID + "\" AND " + EMP_CLINIC_COL_3 + " =\"" + day + "\"";
        Cursor result = db.rawQuery(query, null);
        if (result.getCount() > 0) {
            result.moveToFirst();
            int clinicID = result.getInt(2);
            String tmp = String.valueOf(clinicID);
            String query2 = "SELECT * FROM " + TABLE_CLINICS + " WHERE " + CLINIC_COL_0 + " =\"" + tmp + "\"";
            Cursor clinicResult = db.rawQuery(query2, null);
            if (clinicResult.moveToFirst()) {
                start = clinicResult.getString(4);
            }
        }
        return start;
    }

    public String getClinicCloseTime(int employeeID, String day) {
        String close = "";
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_EMPLOYEE_CLINIC + " WHERE " + EMP_CLINIC_COL_1 + " =\"" + employeeID + "\" AND " + EMP_CLINIC_COL_3 + " =\"" + day + "\"";
        Cursor result = db.rawQuery(query, null);
        if (result.getCount() > 0) {
            result.moveToFirst();
            int clinicID = result.getInt(2);
            String tmp = String.valueOf(clinicID);
            String query2 = "SELECT * FROM " + TABLE_CLINICS + " WHERE " + CLINIC_COL_0 + " =\"" + tmp + "\"";
            Cursor clinicResult = db.rawQuery(query2, null);
            if (clinicResult.moveToFirst()) {
                close = clinicResult.getString(5);
            }
        }
        return close;
    }

    public List<Service> getAllServicesOfferedAtClinics() {
        List<Service> services = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_CLINIC_SERVICES_EMPLOYEE + " ";
        Cursor result = db.rawQuery(query, null);


        if (result.getCount() > 0) {
            int[] serviceIDs = new int[result.getCount()];
            int i = 0;
            while (result.moveToNext()) {
                serviceIDs[i++] = result.getInt(2);
            }

            for (int j = 0; j < result.getCount(); j++) {
                String query2 = "SELECT * FROM " + TABLE_SERVICE + " WHERE " + SERVICE_COL_1 + " =\"" + serviceIDs[j] + "\"";
                Cursor result2 = db.rawQuery(query2, null);

                result2.moveToFirst();

                Service service = new Service(result2.getString(1), result2.getString(2));
                services.add(service);

            }

        }

        db.close();
        return services;

    }


    public List<Clinic> getAllClinicsThatOfferServices() {
        SQLiteDatabase db = this.getReadableDatabase();
        List<Clinic> clinics = new ArrayList<>();
        String query = "SELECT DISTINCT " + CLINIC_SERVICES_1 + " FROM " + TABLE_CLINIC_SERVICES_EMPLOYEE + " ";
        Cursor result = db.rawQuery(query, null);

        int[] clinicIDs = new int[result.getCount()];
        int i = 0;

        if (result.getCount() > 0) {

            while (result.moveToNext()) {
                clinicIDs[i] = result.getInt(0);
                i++;
            }

            for (int j = 0; j < result.getCount(); j++) {
                String query2 = "SELECT *  FROM " + TABLE_CLINICS + " WHERE " + CLINIC_COL_0 + " =\"" + clinicIDs[j] + "\" ";
                Cursor result2 = db.rawQuery(query2, null);
                result2.moveToFirst();
                Clinic clinic = new Clinic(result2.getString(1), result2.getString(3), result2.getString(2), result2.getString(4), result2.getString(5));
                clinics.add(clinic);
            }
        }
        db.close();
        return clinics;
    }


    //make sure parameter are not empty strings

    public List<Clinic> customSearchByClinicInfo(String address, String openAt, String closeAt, String clinicName) {

        SQLiteDatabase db = this.getReadableDatabase();
        List<Clinic> clinics = new ArrayList<>();
        List<Clinic> tmp1 = new ArrayList<>();

        //Search by address
        if (!address.isEmpty()) {
            int[] clinicsFoundByAddressWithServices;
            int i = 0;

            String query1 = "SELECT DISTINCT ID FROM Clinics WHERE Address like '%" + address + "%' ";
            Cursor result1 = db.rawQuery(query1, null);
            if (result1.getCount() > 0) {

                clinicsFoundByAddressWithServices = new int[result1.getCount()];

                while (result1.moveToNext()) {
                    String matchingClinicIDWithServiceID = "SELECT * FROM " + TABLE_CLINIC_SERVICES_EMPLOYEE + " WHERE " + CLINIC_SERVICES_1 + " =\"" + result1.getInt(0) + "\"";
                    Cursor result2 = db.rawQuery(matchingClinicIDWithServiceID, null);
                    if (result2.moveToFirst()) {
                        clinicsFoundByAddressWithServices[i++] = result2.getInt(1);
                    }
                }

                for (int j = 0; j < clinicsFoundByAddressWithServices.length; j++) {
                    String clinicInfo = "SELECT * FROM " + TABLE_CLINICS + " WHERE " + CLINIC_COL_0 + " =\"" + clinicsFoundByAddressWithServices[j] + "\"";
                    Cursor result3 = db.rawQuery(clinicInfo, null);
                    result3.moveToFirst();
                    Clinic clinic = new Clinic(result3.getString(1), result3.getString(3), result3.getString(2), result3.getString(4), result3.getString(5));
                    clinics.add(clinic);
                }
            }

        }


//        return clinicsByAddress;

        //Search by workingHours


        if (!clinicName.isEmpty()) {
            int[] clinicsFoundByNameWithService;
            int a = 0;

            String query2 = "SELECT DISTINCT ID FROM Clinics WHERE name like '%" + clinicName + "%' ";
            Cursor result4 = db.rawQuery(query2, null);
            if (result4.getCount() > 0) {

                clinicsFoundByNameWithService = new int[result4.getCount()];

                while (result4.moveToNext()) {
                    String matchingClinicIDWithServiceID = "SELECT * FROM " + TABLE_CLINIC_SERVICES_EMPLOYEE + " WHERE " + CLINIC_SERVICES_1 + " =\"" + result4.getInt(0) + "\"";
                    Cursor result5 = db.rawQuery(matchingClinicIDWithServiceID, null);
                    if (result5.moveToFirst()) {
                        clinicsFoundByNameWithService[a++] = result5.getInt(1);
                    }
                }

                for (int j = 0; j < clinicsFoundByNameWithService.length; j++) {
                    String clinicInfo = "SELECT * FROM " + TABLE_CLINICS + " WHERE " + CLINIC_COL_0 + " =\"" + clinicsFoundByNameWithService[j] + "\"";
                    Cursor result6 = db.rawQuery(clinicInfo, null);
                    result6.moveToFirst();
                    Clinic clinic = new Clinic(result6.getString(1), result6.getString(3), result6.getString(2), result6.getString(4), result6.getString(5));
                    tmp1.add(clinic);
                }
            }


        }


        return clinics;


    }

    public List<Clinic> customSearchByClinicAddress(String address) {

        SQLiteDatabase db = this.getReadableDatabase();
        List<Clinic> clinics = new ArrayList<>();

        //int[] clinicsFoundByAddressWithServices;
        List<Integer> clinicIDFoundByAddress= new ArrayList<>();
        int i = 0;

        //Search by address
        if (!address.isEmpty()) {


            String query1 = "SELECT DISTINCT ID FROM Clinics WHERE Address like '%" + address + "%' ";
            Cursor result1 = db.rawQuery(query1, null);
            if (result1.getCount() > 0) {

                //clinicsFoundByAddressWithServices = new int[result1.getCount()];

                while (result1.moveToNext()) {
                    String matchingClinicIDWithServiceID = "SELECT * FROM " + TABLE_CLINIC_SERVICES_EMPLOYEE + " WHERE " + CLINIC_SERVICES_1 + " =\"" + result1.getInt(0) + "\"";
                    Cursor result2 = db.rawQuery(matchingClinicIDWithServiceID, null);
                    if (result2.moveToFirst()) {
                        //clinicsFoundByAddressWithServices[i++] = result2.getInt(1);
                        clinicIDFoundByAddress.add(result2.getInt(1));
                    }
                }

                for (int j = 0; j < clinicIDFoundByAddress.size(); j++) {
                    String clinicInfo = "SELECT * FROM " + TABLE_CLINICS + " WHERE " + CLINIC_COL_0 + " =\"" + clinicIDFoundByAddress.get(j) + "\"";
                    Cursor result3 = db.rawQuery(clinicInfo, null);
                    if(result3.moveToFirst()){
                        Clinic clinic = new Clinic(result3.getString(1), result3.getString(3), result3.getString(2), result3.getString(4), result3.getString(5));
                        clinics.add(clinic);
                    }

                }
            }

        }
        db.close();
        return clinics;
    }

    public List<Clinic> customSearchByClinicName(String clinicName){
        SQLiteDatabase db =this.getReadableDatabase();
        List<Clinic> clinics = new ArrayList<>();

        //int[] clinicsFoundByNameWithService;
        List<Integer> clinicIDFoundByName = new ArrayList<>();
        int a = 0;

        String query2 = "SELECT DISTINCT ID FROM Clinics WHERE name like '%" + clinicName + "%' ";
        Cursor result4 = db.rawQuery(query2, null);
        if (result4.getCount() > 0) {

            //clinicsFoundByNameWithService = new int[result4.getCount()];

            while (result4.moveToNext()) {

                String matchingClinicIDWithServiceID = "SELECT * FROM " + TABLE_CLINIC_SERVICES_EMPLOYEE + " WHERE " + CLINIC_SERVICES_1 + " =\"" + result4.getInt(0) + "\"";
                Cursor result5 = db.rawQuery(matchingClinicIDWithServiceID, null);

                if (result5.moveToFirst()) {
               //     clinicsFoundByNameWithService[a++] = result5.getInt(1);
                    clinicIDFoundByName.add(result5.getInt(1));
                }
            }

            for (int j = 0; j < clinicIDFoundByName.size(); j++) {
                String clinicInfo = "SELECT * FROM " + TABLE_CLINICS + " WHERE " + CLINIC_COL_0 + " =\"" + clinicIDFoundByName.get(j) + "\"";
                Cursor result6 = db.rawQuery(clinicInfo, null);
                if(result6.moveToFirst()){
                    Clinic clinic = new Clinic(result6.getString(1), result6.getString(3), result6.getString(2), result6.getString(4), result6.getString(5));
                    clinics.add(clinic);
                }

            }
        }
        db.close();
        return clinics;
    }


    public List<Clinic>  customSearchByClinicOpenAt(String openAt){
        SQLiteDatabase db = this.getReadableDatabase();
        List<Clinic> clinics = new ArrayList<>();
        String[] searchTime = openAt.split(":");
        int hour=Integer.parseInt( searchTime[0]);

        int min= Integer.parseInt( searchTime[1]);
        int lookingTime = (hour*100) + min;


        String query1 = "SELECT * FROM "+TABLE_CLINICS+"";
        Cursor result = db.rawQuery(query1,null);

        if(result.getCount()>0){

            while(result.moveToNext()){
                String open= result.getString(4);
                String [] time = open.split(":");
                int tmp = Integer.parseInt(time[0]+time[1]);

                String close = result.getString(5);
                String [] time2= close.split(":");
                int tmp2 = Integer.parseInt(time2[0]+time[1]);
                if(lookingTime>=tmp && lookingTime<=tmp2){
                    int clinicID = result.getInt(0);

                    String query2 = "SELECT "+CLINIC_SERVICES_1+" FROM "+TABLE_CLINIC_SERVICES_EMPLOYEE+" WHERE "+CLINIC_SERVICES_1+" =\""+clinicID+"\"";
                    Cursor result2 = db.rawQuery(query2,null);
                    if(result2.getCount()>0){

                        String query3 = "SELECT * FROM "+TABLE_CLINICS+" WHERE "+CLINIC_COL_0+" =\""+clinicID+"\"";
                        Cursor result3 = db.rawQuery(query3,null);
                        result3.moveToFirst();
                        Clinic clinic = new Clinic(result3.getString(1),result3.getString(3),result3.getString(2),result3.getString(4),result3.getString(5));
                        clinics.add(clinic);

                    }
                }

            }


        }
        return clinics;
    }



    public List<Clinic> customSearchOfClinicsByService(String service){
        SQLiteDatabase db = this.getReadableDatabase();
        List<Clinic> clinics = new ArrayList<>();
        //int[] clinicsFoundByService;
        List<Integer> clinicIDFoundByService= new ArrayList<>();
        int a = 0;
        String query2 = "SELECT DISTINCT ID FROM Services WHERE SERVICE like '%"+service+"%'";
        Cursor result4 = db.rawQuery(query2, null);

        if (result4.getCount() > 0) {

            //clinicsFoundByService = new int[result4.getCount()];
            while (result4.moveToNext()){

                String matchingClinicIDWithServiceID = "SELECT * FROM " + TABLE_CLINIC_SERVICES_EMPLOYEE + " WHERE " + CLINIC_SERVICES_2 + " =\"" + result4.getInt(0) + "\"";
                Cursor result5 = db.rawQuery(matchingClinicIDWithServiceID, null);

                while (result5.moveToNext()){
                   // clinicsFoundByService[a++] = result5.getInt(1);
                    clinicIDFoundByService.add(result5.getInt(1));
                }
            }

            for (int j = 0; j < clinicIDFoundByService.size(); j++) {

                String clinicInfo = "SELECT * FROM " + TABLE_CLINICS + " WHERE " + CLINIC_COL_0 + " =\"" + clinicIDFoundByService.get(j) + "\"";
                Cursor result6 = db.rawQuery(clinicInfo, null);

                if(result6.moveToFirst()){
                    Clinic clinic = new Clinic(result6.getString(1), result6.getString(3), result6.getString(2), result6.getString(4), result6.getString(5));
                    clinics.add(clinic);
                }
            }
        }
        db.close();
        return clinics;
    }
    /*
    public List<Clinic> customSearchOfClinicsByService(String service){
        SQLiteDatabase db = this.getReadableDatabase();
        List<Clinic> clinics = new ArrayList<>();
        int[] clinicsFoundByService;
        int a = 0;
        String query2 = "SELECT DISTINCT ID FROM Services WHERE SERVICE like '%"+service+"%'";
        Cursor result4 = db.rawQuery(query2, null);

        if (result4.getCount() > 0) {

            clinicsFoundByService = new int[result4.getCount()];
            while (result4.moveToNext()){
                String matchingClinicIDWithServiceID = "SELECT * FROM " + TABLE_CLINIC_SERVICES_EMPLOYEE + " WHERE " + CLINIC_SERVICES_2 + " =\"" + result4.getInt(0) + "\"";
                Cursor result5 = db.rawQuery(matchingClinicIDWithServiceID, null);
                if (result5.moveToFirst()){
                    clinicsFoundByService[a++] = result5.getInt(1);
                }
            }

            for (int j = 0; j < clinicsFoundByService.length; j++) {

                String clinicInfo = "SELECT * FROM " + TABLE_CLINICS + " WHERE " + CLINIC_COL_0 + " =\"" + clinicsFoundByService[j] + "\"";
                Cursor result6 = db.rawQuery(clinicInfo, null);

                if(result6.moveToFirst()){
                    Clinic clinic = new Clinic(result6.getString(1), result6.getString(3), result6.getString(2), result6.getString(4), result6.getString(5));
                    clinics.add(clinic);
                }
            }
        }
        db.close();
        return clinics;
    }

     */


    public Clinic getClinic( String clinicName,String clinicAddress,String clinicPhone){
        SQLiteDatabase db = this.getReadableDatabase();
        Clinic clinic ;


        String query = "SELECT * FROM "+TABLE_CLINICS+" WHERE "+CLINIC_COL_0+" =\""+getClinicID(clinicName,clinicAddress,clinicPhone)+"\"";
        Cursor result = db.rawQuery(query,null);

        if(result.moveToFirst()){
            clinic = new Clinic(result.getString(1),result.getString(3),result.getString(2),result.getString(4),result.getString(5),result.getInt(6),result.getInt(7) );
        }
        else{
            return null;
        }

        return clinic;
    }

    public void addRating(Clinic clinic,int newRating){
        SQLiteDatabase db = this.getWritableDatabase();
        int ID = getClinicID(clinic.getClinicName(),clinic.getAddress(),clinic.getPhoneNumber());
        String query = "SELECT * FROM "+TABLE_CLINICS+" WHERE "+CLINIC_COL_0+" =\""+ID+" \"";
        Cursor result = db.rawQuery(query,null);
        if(result.moveToFirst()){
            ContentValues cv = new ContentValues();
            cv.put(CLINIC_COL_7,result.getInt(7)+1 );
            cv.put(CLINIC_COL_6,result.getInt(6)+newRating );
            db.update(TABLE_CLINICS, cv, "ID=" + ID, null);
        }
    }

    public int[] getRating(int clinicID){
        int[] rating=new int[2];
        SQLiteDatabase db =this.getReadableDatabase();
        String query = "SELECT * FROM "+TABLE_CLINICS+" WHERE "+CLINIC_COL_0+" =\""+clinicID+" \"";
        Cursor result = db.rawQuery(query,null);

        if(result.moveToFirst()){
            int sum =result.getInt(6);
            int num= result.getInt(7);

            rating[0]=sum;
            rating[1]=num;
        }
        return rating;
    }




    public int getWaitTime(int clinicID, String date){
        int waitTime =0;

        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM "+TABLE_PATIENT_APPOINTMENT+" WHERE "+PATIENT_APP_COL_2+" =\""+clinicID+"\" AND "+PATIENT_APP_COL_3+" =\""+date+"\"";
        Cursor result = db.rawQuery(query,null);

        waitTime=result.getCount()*15;
        db.close();
        return  waitTime;
    }

    public void bookAppointment(int patientID, int clinicID, String date, String time){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(PATIENT_APP_COL_1, patientID);
        contentValues.put(PATIENT_APP_COL_2, clinicID);
        contentValues.put(PATIENT_APP_COL_3, date);
        contentValues.put(PATIENT_APP_COL_4, time);

        db.insert(TABLE_PATIENT_APPOINTMENT, null, contentValues);
        db.close();
    }


    public boolean isValideTime(int clinicID,String appTime) {

        String [] appointmentTime = appTime.split(":");
        int hour=Integer.parseInt( appointmentTime[0]);
        int min= Integer.parseInt( appointmentTime[1]);
        int appointment = (hour*100) + min;
        String start="";
        String close = "";


        SQLiteDatabase db = this.getReadableDatabase();
        String query2 = "SELECT * FROM " + TABLE_CLINICS + " WHERE " + CLINIC_COL_0 + " =\"" + clinicID + "\"";
        Cursor clinicResult = db.rawQuery(query2, null);

        if (clinicResult.moveToFirst()) {

            start = clinicResult.getString(4);
            String [] startTime = start.split(":");
            int tmp = Integer.parseInt(startTime[0]+startTime[1]);

            close = clinicResult.getString(5);
            String [] closeTime= close.split(":");
            int tmp2 = Integer.parseInt(closeTime[0]+closeTime[1]);

            if( appointment>tmp && appointment<tmp2){
                return true;
            }
        }
        return false;
    }


    public List<ClinicAppointment> getClinicAppointmentList(int patientID){
        List <ClinicAppointment> clinics=new ArrayList<ClinicAppointment>();
        SQLiteDatabase db =this.getReadableDatabase();
        String query ="SELECT * FROM "+TABLE_PATIENT_APPOINTMENT+" WHERE "+PATIENT_APP_COL_1+" =\""+patientID+"\" ";
        Cursor result = db.rawQuery(query,null);
        if(result.getCount()>0){
            while(result.moveToNext()) {
                String query2 = "SELECT * FROM " + TABLE_CLINICS + " WHERE " + CLINIC_COL_0 + " =\""+result.getInt(2)+"\"";
                Cursor result2= db.rawQuery(query2,null);
                if(result2.moveToFirst()){
                    ClinicAppointment clinicAppointment = new ClinicAppointment(result2.getString(1),result2.getString(2),result2.getString(3),result.getString(3),result.getString(4));
                    clinics.add(clinicAppointment);
                }
            }
        }
        db.close();
        return clinics;
    }


    public int getAppointmentID(int patientID, int clinicID, String date,String time){
        SQLiteDatabase db = this.getReadableDatabase();
        int id=-1;
        String query = "SELECT ID FROM "+TABLE_PATIENT_APPOINTMENT+" WHERE "+PATIENT_APP_COL_1+" =\""+patientID+"\" AND "+PATIENT_APP_COL_2+" =\""+clinicID+"\" AND "+PATIENT_APP_COL_3+" =\""+date+"\" AND "+PATIENT_APP_COL_4+" =\""+time+"\" ";
        Cursor result = db.rawQuery(query,null);
        if(result.moveToFirst()){
            id= result.getInt(0);
        }
        return id;
    }

    public boolean removeAppointment (int appointmentID) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "Select * FROM " + TABLE_PATIENT_APPOINTMENT + " WHERE " + PATIENT_APP_COL_0 + " =\"" + appointmentID + "\"";
        Cursor result = db.rawQuery(query, null);
        if (result.moveToFirst()) {
            db.delete(TABLE_PATIENT_APPOINTMENT, PATIENT_APP_COL_0 + " = " + appointmentID, null);
            return true;
        }
        return false;
    }

}

package com.example.walkinclinicsservicesapp;


import org.junit.Rule;

import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.test.annotation.UiThreadTest;
import androidx.test.rule.ActivityTestRule;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static androidx.test.espresso.Espresso.closeSoftKeyboard;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class SignInTest {

    @Rule
    public ActivityTestRule<SignIn> signInActivityTestRule= new ActivityTestRule<SignIn>(SignIn.class);
    private SignIn signIn=null;




    private EditText userName ,email;


    @Before
    public void setUp() throws Exception{
        signIn=signInActivityTestRule.getActivity();
    }


    @Test
    @UiThreadTest
    public void checkName() throws Exception{

        userName=signIn.findViewById(R.id.editTextUserName);
        userName.setText("admin");
        assertNotNull(signIn.findViewById(R.id.editTextUserName));
        assertEquals("admin",userName.getText().toString());
        assertNotEquals("admin1",userName.getText().toString());
    }

    @Test
    @UiThreadTest
    public void checkEmail() throws Exception{

        email=signIn.findViewById(R.id.editTextEmail);
        email.setText("email@gmail.com");
        assertNotNull(email.findViewById(R.id.editTextEmail));
        assertEquals("email@gmail.com",email.getText().toString());
        assertNotEquals("email2@gmail.com",email.getText().toString());
    }


/* @Test
    
    public void cantCreateAccountWhenUserNameIsEmpty() throws Exception{

        onView(withId(R.id.editTextUserName)).perform(typeText("") );
        onView(withId(R.id.createAccountButton ) ).perform(click());


    }

    @Test
    public void ccButtonDisplaysToast() throws NullPointerException {
        Button button3 = (Button) signIn.findViewById(R.id.createAccountButton);
        createAccountButton.performClick(); // --> this calls the actual onClickListener implementation which has the toast.
                ShadowLooper.idleMainLooper(YOUR_TIME_HERE); --> This may help you.
                assertThat(ShadowToast.getTextOfLatestToast().toString(), equalTo("TEST_YOUR_TEXT_HERE"));
    }

 */
}
